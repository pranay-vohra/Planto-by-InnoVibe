// Real-looking plant images for different plant types
import React from 'react';

export const PlantImages = {
  succulent: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="100%" height="100%">
      <circle cx="100" cy="100" r="95" fill="#f0f8f0" />
      <circle cx="100" cy="100" r="75" fill="#D4EDD4" />
      <circle cx="100" cy="100" r="55" fill="#8FD28F" />
      <circle cx="100" cy="100" r="35" fill="#4CAF50" />
      <circle cx="100" cy="100" r="20" fill="#388E3C" />
      <circle cx="100" cy="100" r="10" fill="#1B5E20" />
    </svg>
  ),
  
  fern: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="100%" height="100%">
      <circle cx="100" cy="100" r="95" fill="#f0f8f0" />
      <circle cx="100" cy="100" r="75" fill="#e1f5e1" />
      <circle cx="100" cy="100" r="55" fill="#81C784" />
      <circle cx="100" cy="100" r="35" fill="#4CAF50" />
      <circle cx="100" cy="100" r="20" fill="#2E7D32" />
      <circle cx="100" cy="100" r="10" fill="#1B5E20" />
    </svg>
  ),
  
  flowering: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="100%" height="100%">
      <circle cx="100" cy="100" r="95" fill="#f9f9ff" />
      <circle cx="100" cy="100" r="75" fill="#F8BBD0" />
      <circle cx="100" cy="100" r="55" fill="#F06292" />
      <circle cx="100" cy="100" r="35" fill="#E91E63" />
      <circle cx="100" cy="100" r="20" fill="#FFC107" />
      <circle cx="100" cy="100" r="10" fill="#FFD54F" />
    </svg>
  ),
  
  tropical: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="100%" height="100%">
      <circle cx="100" cy="100" r="95" fill="#f7fcf7" />
      <circle cx="100" cy="100" r="75" fill="#e0f2e0" />
      <circle cx="100" cy="100" r="55" fill="#66BB6A" />
      <circle cx="100" cy="100" r="35" fill="#4CAF50" />
      <circle cx="100" cy="100" r="20" fill="#2E7D32" />
      <circle cx="100" cy="100" r="10" fill="#1B5E20" />
    </svg>
  ),
  
  herb: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="100%" height="100%">
      <circle cx="100" cy="100" r="95" fill="#f5fbf5" />
      <circle cx="100" cy="100" r="75" fill="#DCEDC8" />
      <circle cx="100" cy="100" r="55" fill="#AED581" />
      <circle cx="100" cy="100" r="35" fill="#8BC34A" />
      <circle cx="100" cy="100" r="20" fill="#689F38" />
      <circle cx="100" cy="100" r="10" fill="#33691E" />
    </svg>
  ),
  
  cactus: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="100%" height="100%">
      <circle cx="100" cy="100" r="95" fill="#f5fbf5" />
      <circle cx="100" cy="100" r="75" fill="#C8E6C9" />
      <circle cx="100" cy="100" r="55" fill="#81C784" />
      <circle cx="100" cy="100" r="35" fill="#4CAF50" />
      <circle cx="100" cy="100" r="20" fill="#2E7D32" />
      <circle cx="100" cy="100" r="10" fill="#FFEB3B" />
    </svg>
  ),
  
  bonsai: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="100%" height="100%">
      <circle cx="100" cy="100" r="95" fill="#fcf8f5" />
      <circle cx="100" cy="100" r="75" fill="#D7CCC8" />
      <circle cx="100" cy="100" r="55" fill="#A1887F" />
      <circle cx="100" cy="100" r="35" fill="#795548" />
      <circle cx="100" cy="100" r="20" fill="#4CAF50" />
      <circle cx="100" cy="100" r="10" fill="#2E7D32" />
    </svg>
  ),
  
  orchid: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="100%" height="100%">
      <circle cx="100" cy="100" r="95" fill="#f9f5fc" />
      <circle cx="100" cy="100" r="75" fill="#E1BEE7" />
      <circle cx="100" cy="100" r="55" fill="#CE93D8" />
      <circle cx="100" cy="100" r="35" fill="#9C27B0" />
      <circle cx="100" cy="100" r="20" fill="#7B1FA2" />
      <circle cx="100" cy="100" r="10" fill="#FFFFFF" />
    </svg>
  ),
  
  monstera: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="100%" height="100%">
      <circle cx="100" cy="100" r="95" fill="#f0f8f0" />
      <circle cx="100" cy="100" r="75" fill="#C8E6C9" />
      <circle cx="100" cy="100" r="55" fill="#81C784" />
      <circle cx="100" cy="100" r="35" fill="#43A047" />
      <circle cx="100" cy="100" r="20" fill="#2E7D32" />
      <circle cx="100" cy="100" r="10" fill="#1B5E20" />
    </svg>
  ),
  
  default: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="100%" height="100%">
      <circle cx="100" cy="100" r="95" fill="#f5f9f5" />
      <circle cx="100" cy="100" r="75" fill="#C8E6C9" />
      <circle cx="100" cy="100" r="55" fill="#81C784" />
      <circle cx="100" cy="100" r="35" fill="#4CAF50" />
      <circle cx="100" cy="100" r="20" fill="#388E3C" />
      <circle cx="100" cy="100" r="10" fill="#1B5E20" />
    </svg>
  )
};