// Real potted plant images (SVG representations)
import React from 'react';

export const PlantImages = {
  succulent: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
      {/* Pot */}
      <path d="M75,180 C75,180 75,250 150,250 C225,250 225,180 225,180 L75,180 Z" fill="#d4d4d4" />
      <path d="M75,180 C75,180 75,250 150,250 C225,250 225,180 225,180 L75,180 Z" fill="none" stroke="#bbbbbb" strokeWidth="2" />
      <path d="M80,180 L220,180" stroke="#bbbbbb" strokeWidth="2" />
      
      {/* Zigzag pattern on pot */}
      <path d="M85,190 L95,210 L105,190 L115,210 L125,190 L135,210 L145,190 L155,210 L165,190 L175,210 L185,190 L195,210 L205,190 L215,210" 
            stroke="#bbbbbb" strokeWidth="2" fill="none" />
            
      {/* Soil */}
      <ellipse cx="150" cy="180" rx="70" ry="15" fill="#8B4513" />
      
      {/* Plant */}
      <g>
        {/* Central stem */}
        <path d="M150,180 C150,180 145,120 150,100" stroke="#558B2F" strokeWidth="4" fill="none" />
        
        {/* Succulent leaves */}
        <path d="M150,160 C170,155 185,145 180,130 C175,115 155,125 150,130" fill="#7CB342" />
        <path d="M150,160 C130,155 115,145 120,130 C125,115 145,125 150,130" fill="#7CB342" />
        <path d="M150,140 C170,135 190,125 180,105 C170,85 155,105 150,110" fill="#8BC34A" />
        <path d="M150,140 C130,135 110,125 120,105 C130,85 145,105 150,110" fill="#8BC34A" />
        <path d="M150,120 C165,115 175,100 165,85 C155,70 145,90 150,95" fill="#AED581" />
        <path d="M150,120 C135,115 125,100 135,85 C145,70 155,90 150,95" fill="#AED581" />
      </g>
    </svg>
  ),
  
  fern: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
      {/* Pot */}
      <path d="M75,180 C75,180 75,250 150,250 C225,250 225,180 225,180 L75,180 Z" fill="#d4d4d4" />
      <path d="M75,180 C75,180 75,250 150,250 C225,250 225,180 225,180 L75,180 Z" fill="none" stroke="#bbbbbb" strokeWidth="2" />
      <path d="M80,180 L220,180" stroke="#bbbbbb" strokeWidth="2" />
      
      {/* Zigzag pattern on pot */}
      <path d="M85,190 L95,210 L105,190 L115,210 L125,190 L135,210 L145,190 L155,210 L165,190 L175,210 L185,190 L195,210 L205,190 L215,210" 
            stroke="#bbbbbb" strokeWidth="2" fill="none" />
            
      {/* Soil */}
      <ellipse cx="150" cy="180" rx="70" ry="15" fill="#8B4513" />
      
      {/* Fern Plant */}
      <g>
        {/* Central stem */}
        <path d="M150,180 C150,180 155,110 150,70" stroke="#33691E" strokeWidth="3" fill="none" />
        
        {/* Fern leaves */}
        <path d="M150,160 C150,160 180,150 200,155" stroke="#689F38" strokeWidth="2" fill="none" />
        <path d="M200,155 C200,155 190,145 185,140" stroke="#689F38" strokeWidth="2" fill="none" />
        <path d="M200,155 C200,155 195,150 185,155" stroke="#689F38" strokeWidth="2" fill="none" />
        <path d="M185,140 C185,140 175,130 170,130" stroke="#689F38" strokeWidth="2" fill="none" />
        <path d="M175,130 C175,130 165,125 160,125" stroke="#689F38" strokeWidth="2" fill="none" />
        
        <path d="M150,160 C150,160 120,150 100,155" stroke="#689F38" strokeWidth="2" fill="none" />
        <path d="M100,155 C100,155 110,145 115,140" stroke="#689F38" strokeWidth="2" fill="none" />
        <path d="M100,155 C100,155 105,150 115,155" stroke="#689F38" strokeWidth="2" fill="none" />
        <path d="M115,140 C115,140 125,130 130,130" stroke="#689F38" strokeWidth="2" fill="none" />
        <path d="M125,130 C125,130 135,125 140,125" stroke="#689F38" strokeWidth="2" fill="none" />
        
        <path d="M150,130 C150,130 180,120 205,125" stroke="#7CB342" strokeWidth="2" fill="none" />
        <path d="M205,125 C205,125 195,115 190,110" stroke="#7CB342" strokeWidth="2" fill="none" />
        <path d="M205,125 C205,125 200,120 190,125" stroke="#7CB342" strokeWidth="2" fill="none" />
        <path d="M190,110 C190,110 180,100 175,100" stroke="#7CB342" strokeWidth="2" fill="none" />
        <path d="M175,100 C175,100 165,95 160,95" stroke="#7CB342" strokeWidth="2" fill="none" />
        
        <path d="M150,130 C150,130 120,120 95,125" stroke="#7CB342" strokeWidth="2" fill="none" />
        <path d="M95,125 C95,125 105,115 110,110" stroke="#7CB342" strokeWidth="2" fill="none" />
        <path d="M95,125 C95,125 100,120 110,125" stroke="#7CB342" strokeWidth="2" fill="none" />
        <path d="M110,110 C110,110 120,100 125,100" stroke="#7CB342" strokeWidth="2" fill="none" />
        <path d="M125,100 C125,100 135,95 140,95" stroke="#7CB342" strokeWidth="2" fill="none" />
        
        <path d="M150,100 C150,100 180,90 210,95" stroke="#8BC34A" strokeWidth="2" fill="none" />
        <path d="M210,95 C210,95 200,85 195,80" stroke="#8BC34A" strokeWidth="2" fill="none" />
        <path d="M210,95 C210,95 205,90 195,95" stroke="#8BC34A" strokeWidth="2" fill="none" />
        <path d="M195,80 C195,80 185,70 180,70" stroke="#8BC34A" strokeWidth="2" fill="none" />
        <path d="M180,70 C180,70 170,65 165,65" stroke="#8BC34A" strokeWidth="2" fill="none" />
        
        <path d="M150,100 C150,100 120,90 90,95" stroke="#8BC34A" strokeWidth="2" fill="none" />
        <path d="M90,95 C90,95 100,85 105,80" stroke="#8BC34A" strokeWidth="2" fill="none" />
        <path d="M90,95 C90,95 95,90 105,95" stroke="#8BC34A" strokeWidth="2" fill="none" />
        <path d="M105,80 C105,80 115,70 120,70" stroke="#8BC34A" strokeWidth="2" fill="none" />
        <path d="M120,70 C120,70 130,65 135,65" stroke="#8BC34A" strokeWidth="2" fill="none" />
      </g>
    </svg>
  ),
  
  flowering: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
      {/* Pot */}
      <path d="M75,180 C75,180 75,250 150,250 C225,250 225,180 225,180 L75,180 Z" fill="#d4d4d4" />
      <path d="M75,180 C75,180 75,250 150,250 C225,250 225,180 225,180 L75,180 Z" fill="none" stroke="#bbbbbb" strokeWidth="2" />
      <path d="M80,180 L220,180" stroke="#bbbbbb" strokeWidth="2" />
      
      {/* Zigzag pattern on pot */}
      <path d="M85,190 L95,210 L105,190 L115,210 L125,190 L135,210 L145,190 L155,210 L165,190 L175,210 L185,190 L195,210 L205,190 L215,210" 
            stroke="#bbbbbb" strokeWidth="2" fill="none" />
            
      {/* Soil */}
      <ellipse cx="150" cy="180" rx="70" ry="15" fill="#8B4513" />
      
      {/* Flowering Plant */}
      <g>
        {/* Stems */}
        <path d="M150,180 C150,180 140,110 130,80" stroke="#558B2F" strokeWidth="2" fill="none" />
        <path d="M150,180 C150,180 170,130 160,80" stroke="#558B2F" strokeWidth="2" fill="none" />
        <path d="M150,180 C150,180 120,130 130,100" stroke="#558B2F" strokeWidth="2" fill="none" />
        <path d="M150,180 C150,180 180,130 175,110" stroke="#558B2F" strokeWidth="2" fill="none" />
        
        {/* Leaves */}
        <path d="M130,150 C110,145 105,130 115,120 C125,110 140,115 130,150 Z" fill="#7CB342" />
        <path d="M170,130 C190,125 195,110 185,100 C175,90 160,95 170,130 Z" fill="#7CB342" />
        <path d="M140,120 C120,110 125,95 135,90 C145,85 155,100 140,120 Z" fill="#7CB342" />
        <path d="M160,140 C180,135 190,120 180,110 C170,100 155,105 160,140 Z" fill="#7CB342" />
        
        {/* Flowers */}
        <circle cx="130" cy="80" r="15" fill="#E91E63" />
        <circle cx="130" cy="80" r="8" fill="#FFC107" />
        
        <circle cx="160" cy="80" r="12" fill="#9C27B0" />
        <circle cx="160" cy="80" r="6" fill="#FFC107" />
        
        <circle cx="130" cy="100" r="10" fill="#F06292" />
        <circle cx="130" cy="100" r="5" fill="#FFC107" />
        
        <circle cx="175" cy="110" r="13" fill="#E91E63" />
        <circle cx="175" cy="110" r="7" fill="#FFC107" />
      </g>
    </svg>
  ),
  
  tropical: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
      {/* Pot */}
      <path d="M75,180 C75,180 75,250 150,250 C225,250 225,180 225,180 L75,180 Z" fill="#d4d4d4" />
      <path d="M75,180 C75,180 75,250 150,250 C225,250 225,180 225,180 L75,180 Z" fill="none" stroke="#bbbbbb" strokeWidth="2" />
      <path d="M80,180 L220,180" stroke="#bbbbbb" strokeWidth="2" />
      
      {/* Zigzag pattern on pot */}
      <path d="M85,190 L95,210 L105,190 L115,210 L125,190 L135,210 L145,190 L155,210 L165,190 L175,210 L185,190 L195,210 L205,190 L215,210" 
            stroke="#bbbbbb" strokeWidth="2" fill="none" />
            
      {/* Soil */}
      <ellipse cx="150" cy="180" rx="70" ry="15" fill="#8B4513" />
      
      {/* Tropical Plant - Large Leaves */}
      <g>
        {/* Stems */}
        <path d="M150,180 C150,180 145,150 155,110" stroke="#558B2F" strokeWidth="3" fill="none" />
        <path d="M150,180 C150,180 170,150 165,130" stroke="#558B2F" strokeWidth="2" fill="none" />
        <path d="M150,180 C150,180 130,150 135,130" stroke="#558B2F" strokeWidth="2" fill="none" />
        
        {/* Large Tropical Leaves */}
        <path d="M155,110 C140,95 110,90 95,110 C80,130 100,150 130,140 C150,135 160,125 155,110 Z" fill="#4CAF50" />
        <path d="M165,130 C175,115 205,110 215,125 C225,140 205,155 180,145 C165,140 155,145 165,130 Z" fill="#4CAF50" />
        <path d="M135,130 C125,115 95,110 85,125 C75,140 95,155 120,145 C135,140 145,145 135,130 Z" fill="#4CAF50" />
        
        <path d="M155,110 C140,95 110,90 95,110 C80,130 100,150 130,140 C150,135 160,125 155,110 Z" fill="none" stroke="#388E3C" strokeWidth="1" />
        <path d="M165,130 C175,115 205,110 215,125 C225,140 205,155 180,145 C165,140 155,145 165,130 Z" fill="none" stroke="#388E3C" strokeWidth="1" />
        <path d="M135,130 C125,115 95,110 85,125 C75,140 95,155 120,145 C135,140 145,145 135,130 Z" fill="none" stroke="#388E3C" strokeWidth="1" />
      </g>
    </svg>
  ),
  
  herb: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
      {/* Pot */}
      <path d="M75,180 C75,180 75,250 150,250 C225,250 225,180 225,180 L75,180 Z" fill="#d4d4d4" />
      <path d="M75,180 C75,180 75,250 150,250 C225,250 225,180 225,180 L75,180 Z" fill="none" stroke="#bbbbbb" strokeWidth="2" />
      <path d="M80,180 L220,180" stroke="#bbbbbb" strokeWidth="2" />
      
      {/* Zigzag pattern on pot */}
      <path d="M85,190 L95,210 L105,190 L115,210 L125,190 L135,210 L145,190 L155,210 L165,190 L175,210 L185,190 L195,210 L205,190 L215,210" 
            stroke="#bbbbbb" strokeWidth="2" fill="none" />
            
      {/* Soil */}
      <ellipse cx="150" cy="180" rx="70" ry="15" fill="#8B4513" />
      
      {/* Herb Plant */}
      <g>
        {/* Main stems */}
        <path d="M150,180 C150,180 145,150 140,120" stroke="#558B2F" strokeWidth="2" fill="none" />
        <path d="M150,180 C150,180 160,150 155,130" stroke="#558B2F" strokeWidth="2" fill="none" />
        <path d="M150,180 C150,180 170,160 165,140" stroke="#558B2F" strokeWidth="2" fill="none" />
        <path d="M150,180 C150,180 130,160 135,140" stroke="#558B2F" strokeWidth="2" fill="none" />
        <path d="M150,180 C150,180 120,165 125,150" stroke="#558B2F" strokeWidth="2" fill="none" />
        
        {/* Herb Leaves - Basil/Mint style */}
        <path d="M140,120 C135,115 130,115 125,120 C120,125 125,135 135,135 C145,135 145,125 140,120 Z" fill="#8BC34A" />
        <path d="M155,130 C150,125 145,125 140,130 C135,135 140,145 150,145 C160,145 160,135 155,130 Z" fill="#8BC34A" />
        <path d="M165,140 C160,135 155,135 150,140 C145,145 150,155 160,155 C170,155 170,145 165,140 Z" fill="#8BC34A" />
        <path d="M135,140 C130,135 125,135 120,140 C115,145 120,155 130,155 C140,155 140,145 135,140 Z" fill="#8BC34A" />
        <path d="M125,150 C120,145 115,145 110,150 C105,155 110,165 120,165 C130,165 130,155 125,150 Z" fill="#8BC34A" />
        
        {/* Leaf veins */}
        <path d="M140,120 L135,135" stroke="#689F38" strokeWidth="1" fill="none" />
        <path d="M155,130 L150,145" stroke="#689F38" strokeWidth="1" fill="none" />
        <path d="M165,140 L160,155" stroke="#689F38" strokeWidth="1" fill="none" />
        <path d="M135,140 L130,155" stroke="#689F38" strokeWidth="1" fill="none" />
        <path d="M125,150 L120,165" stroke="#689F38" strokeWidth="1" fill="none" />
      </g>
    </svg>
  ),
  
  cactus: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
      {/* Pot */}
      <path d="M75,180 C75,180 75,250 150,250 C225,250 225,180 225,180 L75,180 Z" fill="#d4d4d4" />
      <path d="M75,180 C75,180 75,250 150,250 C225,250 225,180 225,180 L75,180 Z" fill="none" stroke="#bbbbbb" strokeWidth="2" />
      <path d="M80,180 L220,180" stroke="#bbbbbb" strokeWidth="2" />
      
      {/* Zigzag pattern on pot */}
      <path d="M85,190 L95,210 L105,190 L115,210 L125,190 L135,210 L145,190 L155,210 L165,190 L175,210 L185,190 L195,210 L205,190 L215,210" 
            stroke="#bbbbbb" strokeWidth="2" fill="none" />
            
      {/* Soil */}
      <ellipse cx="150" cy="180" rx="70" ry="15" fill="#8B4513" />
      
      {/* Cactus */}
      <g>
        {/* Main cactus body */}
        <path d="M130,180 C130,180 125,130 125,100 C125,75 135,70 150,70 C165,70 175,75 175,100 C175,130 170,180 170,180 Z" fill="#4CAF50" />
        
        {/* Small arm */}
        <path d="M175,130 C175,130 185,125 200,125 C215,125 215,135 215,145 C215,155 210,160 195,160 C180,160 175,155 175,155 Z" fill="#4CAF50" />
        
        {/* Cactus details and spines */}
        <path d="M130,180 C130,180 125,130 125,100 C125,75 135,70 150,70 C165,70 175,75 175,100 C175,130 170,180 170,180 Z" fill="none" stroke="#388E3C" strokeWidth="2" />
        <path d="M175,130 C175,130 185,125 200,125 C215,125 215,135 215,145 C215,155 210,160 195,160 C180,160 175,155 175,155 Z" fill="none" stroke="#388E3C" strokeWidth="2" />
        
        {/* Spines */}
        <line x1="125" y1="100" x2="115" y2="95" stroke="#FFEB3B" strokeWidth="2" />
        <line x1="125" y1="120" x2="115" y2="115" stroke="#FFEB3B" strokeWidth="2" />
        <line x1="125" y1="140" x2="115" y2="135" stroke="#FFEB3B" strokeWidth="2" />
        <line x1="125" y1="160" x2="115" y2="155" stroke="#FFEB3B" strokeWidth="2" />
        
        <line x1="175" y1="100" x2="185" y2="95" stroke="#FFEB3B" strokeWidth="2" />
        <line x1="175" y1="120" x2="185" y2="115" stroke="#FFEB3B" strokeWidth="2" />
        <line x1="175" y1="140" x2="185" y2="135" stroke="#FFEB3B" strokeWidth="2" />
        <line x1="175" y1="160" x2="185" y2="155" stroke="#FFEB3B" strokeWidth="2" />
        
        <line x1="195" y1="125" x2="195" y2="115" stroke="#FFEB3B" strokeWidth="2" />
        <line x1="205" y1="130" x2="215" y2="125" stroke="#FFEB3B" strokeWidth="2" />
        <line x1="205" y1="145" x2="215" y2="145" stroke="#FFEB3B" strokeWidth="2" />
        <line x1="195" y1="155" x2="195" y2="165" stroke="#FFEB3B" strokeWidth="2" />
        
        {/* Flower */}
        <circle cx="150" cy="70" r="8" fill="#FF4081" />
        <circle cx="150" cy="70" r="4" fill="#FFC107" />
      </g>
    </svg>
  ),
  
  bonsai: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
      {/* Pot */}
      <path d="M75,180 C75,180 75,250 150,250 C225,250 225,180 225,180 L75,180 Z" fill="#d4d4d4" />
      <path d="M75,180 C75,180 75,250 150,250 C225,250 225,180 225,180 L75,180 Z" fill="none" stroke="#bbbbbb" strokeWidth="2" />
      <path d="M80,180 L220,180" stroke="#bbbbbb" strokeWidth="2" />
      
      {/* Zigzag pattern on pot */}
      <path d="M85,190 L95,210 L105,190 L115,210 L125,190 L135,210 L145,190 L155,210 L165,190 L175,210 L185,190 L195,210 L205,190 L215,210" 
            stroke="#bbbbbb" strokeWidth="2" fill="none" />
            
      {/* Soil */}
      <ellipse cx="150" cy="180" rx="70" ry="15" fill="#8B4513" />
      
      {/* Bonsai Tree */}
      <g>
        {/* Main trunk */}
        <path d="M150,180 C150,180 140,160 145,140 C150,120 160,110 150,90 C140,70 130,70 120,60" 
              fill="none" stroke="#795548" strokeWidth="10" strokeLinecap="round" />
              
        {/* Branches */}
        <path d="M145,140 C145,140 125,130 110,140" fill="none" stroke="#795548" strokeWidth="5" strokeLinecap="round" />
        <path d="M150,90 C150,90 170,80 180,90" fill="none" stroke="#795548" strokeWidth="5" strokeLinecap="round" />
        <path d="M120,60 C120,60 110,50 100,55" fill="none" stroke="#795548" strokeWidth="3" strokeLinecap="round" />
        <path d="M120,60 C120,60 130,40 125,30" fill="none" stroke="#795548" strokeWidth="3" strokeLinecap="round" />
        
        {/* Foliage */}
        <circle cx="110" cy="140" r="15" fill="#4CAF50" />
        <circle cx="125" cy="125" r="10" fill="#4CAF50" />
        <circle cx="180" cy="90" r="15" fill="#4CAF50" />
        <circle cx="165" cy="80" r="10" fill="#4CAF50" />
        <circle cx="100" cy="55" r="10" fill="#4CAF50" />
        <circle cx="125" cy="30" r="12" fill="#4CAF50" />
        <circle cx="120" cy="45" r="10" fill="#4CAF50" />
      </g>
    </svg>
  ),
  
  orchid: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
      {/* Pot */}
      <path d="M75,180 C75,180 75,250 150,250 C225,250 225,180 225,180 L75,180 Z" fill="#d4d4d4" />
      <path d="M75,180 C75,180 75,250 150,250 C225,250 225,180 225,180 L75,180 Z" fill="none" stroke="#bbbbbb" strokeWidth="2" />
      <path d="M80,180 L220,180" stroke="#bbbbbb" strokeWidth="2" />
      
      {/* Zigzag pattern on pot */}
      <path d="M85,190 L95,210 L105,190 L115,210 L125,190 L135,210 L145,190 L155,210 L165,190 L175,210 L185,190 L195,210 L205,190 L215,210" 
            stroke="#bbbbbb" strokeWidth="2" fill="none" />
            
      {/* Soil */}
      <ellipse cx="150" cy="180" rx="70" ry="15" fill="#8B4513" />
      
      {/* Orchid Plant */}
      <g>
        {/* Main stem */}
        <path d="M150,180 C150,180 155,150 145,130 C135,110 140,90 145,70" 
              fill="none" stroke="#9C27B0" strokeWidth="2" strokeLinecap="round" />
              
        {/* Side stems */}
        <path d="M145,130 C145,130 125,120 115,105" fill="none" stroke="#9C27B0" strokeWidth="2" strokeLinecap="round" />
        <path d="M145,130 C145,130 165,125 175,115" fill="none" stroke="#9C27B0" strokeWidth="2" strokeLinecap="round" />
        <path d="M145,90 C145,90 125,85 120,70" fill="none" stroke="#9C27B0" strokeWidth="2" strokeLinecap="round" />
        
        {/* Leaves at base */}
        <path d="M150,180 C120,170 100,160 110,140 C120,120 150,140 150,180 Z" fill="#4CAF50" />
        <path d="M150,180 C180,170 200,160 190,140 C180,120 150,140 150,180 Z" fill="#4CAF50" />
        
        {/* Orchid flowers */}
        <g transform="translate(115,105)">
          <path d="M0,0 C-10,-5 -15,-15 -10,-20 C-5,-25 5,-20 10,-15 C15,-10 10,0 0,0 Z" fill="#E1BEE7" />
          <path d="M0,0 C10,-5 15,-15 10,-20 C5,-25 -5,-20 -10,-15 C-15,-10 -10,0 0,0 Z" fill="#E1BEE7" />
          <path d="M0,0 C-5,-10 -15,-15 -20,-10 C-25,-5 -20,5 -15,10 C-10,15 0,10 0,0 Z" fill="#E1BEE7" />
          <path d="M0,0 C5,-10 15,-15 20,-10 C25,-5 20,5 15,10 C10,15 0,10 0,0 Z" fill="#E1BEE7" />
          <circle cx="0" cy="0" r="5" fill="#9C27B0" />
        </g>
        
        <g transform="translate(175,115)">
          <path d="M0,0 C-10,-5 -15,-15 -10,-20 C-5,-25 5,-20 10,-15 C15,-10 10,0 0,0 Z" fill="#E1BEE7" />
          <path d="M0,0 C10,-5 15,-15 10,-20 C5,-25 -5,-20 -10,-15 C-15,-10 -10,0 0,0 Z" fill="#E1BEE7" />
          <path d="M0,0 C-5,-10 -15,-15 -20,-10 C-25,-5 -20,5 -15,10 C-10,15 0,10 0,0 Z" fill="#E1BEE7" />
          <path d="M0,0 C5,-10 15,-15 20,-10 C25,-5 20,5 15,10 C10,15 0,10 0,0 Z" fill="#E1BEE7" />
          <circle cx="0" cy="0" r="5" fill="#9C27B0" />
        </g>
        
        <g transform="translate(120,70)">
          <path d="M0,0 C-10,-5 -15,-15 -10,-20 C-5,-25 5,-20 10,-15 C15,-10 10,0 0,0 Z" fill="#E1BEE7" />
          <path d="M0,0 C10,-5 15,-15 10,-20 C5,-25 -5,-20 -10,-15 C-15,-10 -10,0 0,0 Z" fill="#E1BEE7" />
          <path d="M0,0 C-5,-10 -15,-15 -20,-10 C-25,-5 -20,5 -15,10 C-10,15 0,10 0,0 Z" fill="#E1BEE7" />
          <path d="M0,0 C5,-10 15,-15 20,-10 C25,-5 20,5 15,10 C10,15 0,10 0,0 Z" fill="#E1BEE7" />
          <circle cx="0" cy="0" r="5" fill="#9C27B0" />
        </g>
        
        <g transform="translate(145,70)">
          <path d="M0,0 C-8,-4 -12,-12 -8,-16 C-4,-20 4,-16 8,-12 C12,-8 8,0 0,0 Z" fill="#E1BEE7" />
          <path d="M0,0 C8,-4 12,-12 8,-16 C4,-20 -4,-16 -8,-12 C-12,-8 -8,0 0,0 Z" fill="#E1BEE7" />
          <path d="M0,0 C-4,-8 -12,-12 -16,-8 C-20,-4 -16,4 -12,8 C-8,12 0,8 0,0 Z" fill="#E1BEE7" />
          <path d="M0,0 C4,-8 12,-12 16,-8 C20,-4 16,4 12,8 C8,12 0,8 0,0 Z" fill="#E1BEE7" />
          <circle cx="0" cy="0" r="4" fill="#9C27B0" />
        </g>
      </g>
    </svg>
  ),
  
  monstera: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
      {/* Pot */}
      <path d="M75,180 C75,180 75,250 150,250 C225,250 225,180 225,180 L75,180 Z" fill="#d4d4d4" />
      <path d="M75,180 C75,180 75,250 150,250 C225,250 225,180 225,180 L75,180 Z" fill="none" stroke="#bbbbbb" strokeWidth="2" />
      <path d="M80,180 L220,180" stroke="#bbbbbb" strokeWidth="2" />
      
      {/* Zigzag pattern on pot */}
      <path d="M85,190 L95,210 L105,190 L115,210 L125,190 L135,210 L145,190 L155,210 L165,190 L175,210 L185,190 L195,210 L205,190 L215,210" 
            stroke="#bbbbbb" strokeWidth="2" fill="none" />
            
      {/* Soil */}
      <ellipse cx="150" cy="180" rx="70" ry="15" fill="#8B4513" />
      
      {/* Monstera Plant */}
      <g>
        {/* Stems */}
        <path d="M150,180 C150,180 130,150 110,130" fill="none" stroke="#558B2F" strokeWidth="4" strokeLinecap="round" />
        <path d="M150,180 C150,180 145,140 135,110" fill="none" stroke="#558B2F" strokeWidth="4" strokeLinecap="round" />
        <path d="M150,180 C150,180 160,150 180,130" fill="none" stroke="#558B2F" strokeWidth="4" strokeLinecap="round" />
        <path d="M150,180 C150,180 170,140 170,110" fill="none" stroke="#558B2F" strokeWidth="4" strokeLinecap="round" />
        
        {/* Monstera Leaves */}
        <path d="M110,130 C95,120 80,105 90,90 C100,75 120,80 130,95 C140,110 125,125 110,130 Z" fill="#4CAF50" />
        <path d="M110,130 C95,120 80,105 90,90 C100,75 120,80 130,95 C140,110 125,125 110,130 Z" fill="none" stroke="#388E3C" strokeWidth="1" />
        
        {/* Leaf holes */}
        <path d="M100,105 C95,100 95,95 100,90 C105,85 110,90 110,95 C110,100 105,105 100,105 Z" fill="#d4d4d4" />
        
        <path d="M135,110 C120,95 115,75 135,65 C155,55 170,70 165,90 C160,110 150,125 135,110 Z" fill="#4CAF50" />
        <path d="M135,110 C120,95 115,75 135,65 C155,55 170,70 165,90 C160,110 150,125 135,110 Z" fill="none" stroke="#388E3C" strokeWidth="1" />
        
        {/* Leaf holes */}
        <path d="M135,85 C130,80 130,70 140,65 C150,60 155,70 150,80 C145,90 140,90 135,85 Z" fill="#d4d4d4" />
        <path d="M155,90 C150,85 155,75 160,75 C165,75 170,80 165,85 C160,90 160,95 155,90 Z" fill="#d4d4d4" />
        
        <path d="M180,130 C195,120 210,105 200,90 C190,75 170,80 160,95 C150,110 165,125 180,130 Z" fill="#4CAF50" />
        <path d="M180,130 C195,120 210,105 200,90 C190,75 170,80 160,95 C150,110 165,125 180,130 Z" fill="none" stroke="#388E3C" strokeWidth="1" />
        
        {/* Leaf holes */}
        <path d="M190,105 C195,100 195,95 190,90 C185,85 180,90 180,95 C180,100 185,105 190,105 Z" fill="#d4d4d4" />
        
        <path d="M170,110 C185,95 190,75 170,65 C150,55 135,70 140,90 C145,110 155,125 170,110 Z" fill="#4CAF50" />
        <path d="M170,110 C185,95 190,75 170,65 C150,55 135,70 140,90 C145,110 155,125 170,110 Z" fill="none" stroke="#388E3C" strokeWidth="1" />
        
        {/* Leaf holes */}
        <path d="M170,85 C175,80 175,70 165,65 C155,60 150,70 155,80 C160,90 165,90 170,85 Z" fill="#d4d4d4" />
        <path d="M150,90 C155,85 150,75 145,75 C140,75 135,80 140,85 C145,90 145,95 150,90 Z" fill="#d4d4d4" />
      </g>
    </svg>
  ),
  
  default: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
      {/* Pot */}
      <path d="M75,180 C75,180 75,250 150,250 C225,250 225,180 225,180 L75,180 Z" fill="#d4d4d4" />
      <path d="M75,180 C75,180 75,250 150,250 C225,250 225,180 225,180 L75,180 Z" fill="none" stroke="#bbbbbb" strokeWidth="2" />
      <path d="M80,180 L220,180" stroke="#bbbbbb" strokeWidth="2" />
      
      {/* Zigzag pattern on pot */}
      <path d="M85,190 L95,210 L105,190 L115,210 L125,190 L135,210 L145,190 L155,210 L165,190 L175,210 L185,190 L195,210 L205,190 L215,210" 
            stroke="#bbbbbb" strokeWidth="2" fill="none" />
            
      {/* Soil */}
      <ellipse cx="150" cy="180" rx="70" ry="15" fill="#8B4513" />
      
      {/* Generic Plant */}
      <g>
        {/* Stems */}
        <path d="M150,180 C150,180 140,150 130,120" fill="none" stroke="#558B2F" strokeWidth="2" strokeLinecap="round" />
        <path d="M150,180 C150,180 160,140 150,110" fill="none" stroke="#558B2F" strokeWidth="2" strokeLinecap="round" />
        <path d="M150,180 C150,180 170,150 160,130" fill="none" stroke="#558B2F" strokeWidth="2" strokeLinecap="round" />
        <path d="M150,180 C150,180 130,150 140,130" fill="none" stroke="#558B2F" strokeWidth="2" strokeLinecap="round" />
        
        {/* Leaves */}
        <path d="M130,120 C115,115 105,100 115,90 C125,80 140,90 130,120 Z" fill="#4CAF50" />
        <path d="M150,110 C135,100 130,80 145,70 C160,60 165,80 150,110 Z" fill="#4CAF50" />
        <path d="M160,130 C175,125 190,115 185,100 C180,85 165,95 160,130 Z" fill="#4CAF50" />
        <path d="M140,130 C125,125 110,115 115,100 C120,85 135,95 140,130 Z" fill="#4CAF50" />
        
        {/* Leaf veins */}
        <path d="M130,120 C125,110 120,100 115,90" fill="none" stroke="#388E3C" strokeWidth="1" />
        <path d="M150,110 C145,95 145,80 145,70" fill="none" stroke="#388E3C" strokeWidth="1" />
        <path d="M160,130 C165,120 175,110 185,100" fill="none" stroke="#388E3C" strokeWidth="1" />
        <path d="M140,130 C135,120 125,110 115,100" fill="none" stroke="#388E3C" strokeWidth="1" />
      </g>
    </svg>
  )
};