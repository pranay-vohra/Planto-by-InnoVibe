import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

export const AuthPage = () => {
  const { login, register } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<string>('login');
  
  // Login form state
  const [loginForm, setLoginForm] = useState({
    username: '',
    password: ''
  });

  // Register form state
  const [registerForm, setRegisterForm] = useState({
    plantName: '',
    plantType: '',
    username: '',
    password: '',
    wifiUsername: '',
    wifiPassword: '',
    email: '',
    contactNumber: ''
  });

  const handleLoginChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setLoginForm({
      ...loginForm,
      [e.target.name]: e.target.value
    });
  };

  const handleRegisterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setRegisterForm({
      ...registerForm,
      [e.target.name]: e.target.value
    });
  };

  const handlePlantTypeChange = (value: string) => {
    setRegisterForm({
      ...registerForm,
      plantType: value
    });
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!loginForm.username || !loginForm.password) {
      toast({
        title: "Error",
        description: "Please enter both username and password",
        variant: "destructive"
      });
      return;
    }

    try {
      await login(loginForm.username, loginForm.password);
    } catch (error) {
      toast({
        title: "Login Failed",
        description: error instanceof Error ? error.message : "Invalid username or password",
        variant: "destructive"
      });
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required fields
    if (!registerForm.plantName || !registerForm.plantType || !registerForm.username || !registerForm.password) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    try {
      await register(registerForm);
    } catch (error) {
      toast({
        title: "Registration Failed",
        description: error instanceof Error ? error.message : "Unable to register. Please try again.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <Card className="w-full max-w-md bg-white bg-opacity-95">
        <CardContent className="pt-6">
          <div className="text-center mb-6">
            <h2 className="text-3xl font-poppins font-bold text-primary">Welcome to Planto</h2>
            <p className="mt-2 text-sm text-gray-600">Your personal plant companion</p>
          </div>
          
          <Tabs defaultValue="login" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="login">Login</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>
            
            <TabsContent value="login">
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="login-username">Username</Label>
                  <Input 
                    id="login-username" 
                    name="username" 
                    type="text" 
                    value={loginForm.username}
                    onChange={handleLoginChange}
                    required 
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="login-password">Password</Label>
                  <Input 
                    id="login-password" 
                    name="password" 
                    type="password" 
                    value={loginForm.password}
                    onChange={handleLoginChange}
                    required 
                  />
                </div>
                
                <Button type="submit" className="w-full mt-4">
                  Login
                </Button>
              </form>
            </TabsContent>
            
            <TabsContent value="register">
              <form onSubmit={handleRegisterSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="plant-name">Plant Name</Label>
                    <Input 
                      id="plant-name" 
                      name="plantName" 
                      value={registerForm.plantName}
                      onChange={handleRegisterChange}
                      required 
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="plant-type">Plant Type</Label>
                    <Select 
                      value={registerForm.plantType} 
                      onValueChange={handlePlantTypeChange}
                    >
                      <SelectTrigger id="plant-type">
                        <SelectValue placeholder="Select a type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="succulent">Succulent</SelectItem>
                        <SelectItem value="fern">Fern</SelectItem>
                        <SelectItem value="flowering">Flowering</SelectItem>
                        <SelectItem value="tropical">Tropical</SelectItem>
                        <SelectItem value="herb">Herb</SelectItem>
                        <SelectItem value="cactus">Cactus</SelectItem>
                        <SelectItem value="bonsai">Bonsai</SelectItem>
                        <SelectItem value="orchid">Orchid</SelectItem>
                        <SelectItem value="monstera">Monstera</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="register-username">Username</Label>
                  <Input 
                    id="register-username" 
                    name="username" 
                    value={registerForm.username}
                    onChange={handleRegisterChange}
                    required 
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="register-password">Password</Label>
                  <Input 
                    id="register-password" 
                    name="password" 
                    type="password" 
                    value={registerForm.password}
                    onChange={handleRegisterChange}
                    required 
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="wifi-username">WiFi Username</Label>
                  <Input 
                    id="wifi-username" 
                    name="wifiUsername" 
                    value={registerForm.wifiUsername}
                    onChange={handleRegisterChange}
                    required 
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="wifi-password">WiFi Password</Label>
                  <Input 
                    id="wifi-password" 
                    name="wifiPassword" 
                    type="password" 
                    value={registerForm.wifiPassword}
                    onChange={handleRegisterChange}
                    required 
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input 
                    id="email" 
                    name="email" 
                    type="email" 
                    value={registerForm.email}
                    onChange={handleRegisterChange}
                    required 
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="contact-number">Contact Number</Label>
                  <Input 
                    id="contact-number" 
                    name="contactNumber" 
                    type="tel" 
                    value={registerForm.contactNumber}
                    onChange={handleRegisterChange}
                    required 
                  />
                </div>
                
                <Button type="submit" className="w-full mt-4">
                  Register
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default AuthPage;
