import { useState } from 'react';
import { useLocation } from 'wouter';
import { LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { PlantMoodEmojis } from '@/assets/plantIllustrations';
import { PlantImages } from '@/assets/realPlantImages';
import { usePlantData } from '@/hooks/usePlantData';
import DetailedStats from './DetailedStats';
import GraphView from './GraphView';
import { useAuth } from '@/contexts/AuthContext';

export const Dashboard = () => {
  const { userData, logout } = useAuth();
  const { plantData, isLoading } = usePlantData();
  const [activeView, setActiveView] = useState<'dashboard' | 'stats' | 'graph'>('dashboard');
  const [location, setLocation] = useLocation();

  const handleLogout = () => {
    logout();
    setLocation('/');
  };

  const getMoodEmoji = (mood: number) => {
    if (mood >= 0 && mood <= 20) return PlantMoodEmojis.verySad;
    if (mood > 20 && mood <= 40) return PlantMoodEmojis.sad;
    if (mood > 40 && mood <= 60) return PlantMoodEmojis.okay;
    if (mood > 60 && mood <= 80) return PlantMoodEmojis.happy;
    return PlantMoodEmojis.veryHappy;
  };

  const getMoodText = (mood: number) => {
    if (mood >= 0 && mood <= 20) return "Very Sad";
    if (mood > 20 && mood <= 40) return "Sad";
    if (mood > 40 && mood <= 60) return "Okay";
    if (mood > 60 && mood <= 80) return "Happy";
    return "Very Happy";
  };

  const getPlantImage = () => {
    const type = userData?.plantType || 'default';
    return PlantImages[type as keyof typeof PlantImages] || PlantImages.default;
  };

  return (
    <div className="min-h-screen pb-16">
      <header className="bg-primary text-white shadow-md">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-poppins font-semibold">Planto</h1>
          </div>
          <Button 
            variant="ghost" 
            className="text-white hover:bg-white hover:bg-opacity-20"
            onClick={handleLogout}
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </header>
      
      <main className="container mx-auto px-4 py-6">
        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-pulse-slow text-primary">Loading plant data...</div>
          </div>
        ) : (
          <>
            {/* Plant Profile Card */}
            <Card className="bg-white rounded-xl shadow-md mb-6">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row items-center">
                  <div className="w-full md:w-1/3 flex justify-center mb-4 md:mb-0">
                    <div className="w-48 h-48 flex items-center justify-center overflow-hidden">
                      {getPlantImage()}
                    </div>
                  </div>
                  
                  <div className="w-full md:w-2/3 md:pl-6">
                    <h2 className="text-2xl font-poppins font-semibold text-primary">
                      {userData?.plantName || 'My Plant'}
                    </h2>
                    <p className="text-gray-600 mb-3 capitalize">
                      {userData?.plantType || 'Plant'} 
                    </p>
                    
                    <div className="relative plant-message bg-white rounded-lg p-4 border border-gray-200 shadow-sm mb-4">
                      <p className="font-handwritten text-lg">
                        {plantData?.message || "I'm feeling great today! Hydrated and sun-kissed."}
                      </p>
                    </div>
                    
                    <div className="mb-4">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium text-gray-700">Plant Mood</span>
                        <span className="text-sm font-medium">
                          {getMoodText(plantData?.mood || 75)} {getMoodEmoji(plantData?.mood || 75)}
                        </span>
                      </div>
                      <input 
                        type="range" 
                        min="0" 
                        max="100" 
                        value={plantData?.mood || 75} 
                        className="mood-slider w-full" 
                        disabled 
                      />
                      <div className="flex justify-between text-xs text-gray-500 mt-1">
                        <span>{PlantMoodEmojis.verySad}</span>
                        <span>{PlantMoodEmojis.sad}</span>
                        <span>{PlantMoodEmojis.okay}</span>
                        <span>{PlantMoodEmojis.happy}</span>
                        <span>{PlantMoodEmojis.veryHappy}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Sensor Data Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              {/* Moisture Card */}
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center mb-3">
                    <div className="p-2 rounded-full bg-blue-100 text-blue-500 mr-3">
                      <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"></path>
                      </svg>
                    </div>
                    <h3 className="font-poppins font-medium">Soil Moisture</h3>
                  </div>
                  <div className="flex items-end justify-between">
                    <div className="text-3xl font-semibold">{plantData?.moisture || 0}%</div>
                    <div className="text-sm text-gray-500">Optimal: 65-75%</div>
                  </div>
                  <Progress value={plantData?.moisture || 0} className="h-2 mt-2" />
                </CardContent>
              </Card>
              
              {/* Sunlight Card */}
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center mb-3">
                    <div className="p-2 rounded-full bg-yellow-100 text-yellow-500 mr-3">
                      <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="12" cy="12" r="5"></circle>
                        <line x1="12" y1="1" x2="12" y2="3"></line>
                        <line x1="12" y1="21" x2="12" y2="23"></line>
                        <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
                        <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
                        <line x1="1" y1="12" x2="3" y2="12"></line>
                        <line x1="21" y1="12" x2="23" y2="12"></line>
                        <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
                        <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
                      </svg>
                    </div>
                    <h3 className="font-poppins font-medium">Sunlight</h3>
                  </div>
                  <div className="flex items-end justify-between">
                    <div className="text-3xl font-semibold">{plantData?.sunlight || 0} lux</div>
                    <div className="text-sm text-gray-500">Optimal: 800-1200 lux</div>
                  </div>
                  <Progress 
                    value={Math.min(100, (plantData?.sunlight || 0) / 20)} 
                    className="h-2 mt-2" 
                  />
                </CardContent>
              </Card>
              
              {/* Air Quality Card */}
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center mb-3">
                    <div className="p-2 rounded-full bg-green-100 text-green-500 mr-3">
                      <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M2 12h6"></path>
                        <path d="M22 12h-6"></path>
                        <path d="M12 2v6"></path>
                        <path d="M12 22v-6"></path>
                        <path d="M15 5l-3 3-3-3"></path>
                        <path d="M9 19l3-3 3 3"></path>
                        <path d="M19 9l-3 3-3-3"></path>
                        <path d="M5 15l3-3 3 3"></path>
                      </svg>
                    </div>
                    <h3 className="font-poppins font-medium">Air Quality</h3>
                  </div>
                  <div className="flex items-end justify-between">
                    <div className="text-3xl font-semibold">{plantData?.airQuality || 'Good'}</div>
                    <div className="text-sm text-gray-500">CO₂: {plantData?.co2 || 420} ppm</div>
                  </div>
                  <Progress value={plantData?.airQualityValue || 80} className="h-2 mt-2" />
                </CardContent>
              </Card>
            </div>
            
            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <Button 
                variant={activeView === 'stats' ? 'default' : 'outline'}
                className="flex-1 py-6"
                onClick={() => setActiveView(activeView === 'stats' ? 'dashboard' : 'stats')}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                  <polyline points="14 2 14 8 20 8"></polyline>
                  <line x1="16" y1="13" x2="8" y2="13"></line>
                  <line x1="16" y1="17" x2="8" y2="17"></line>
                  <polyline points="10 9 9 9 8 9"></polyline>
                </svg>
                Detailed Stats
              </Button>
              
              <Button 
                variant={activeView === 'graph' ? 'default' : 'outline'}
                className="flex-1 py-6"
                onClick={() => setActiveView(activeView === 'graph' ? 'dashboard' : 'graph')}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="18" y1="20" x2="18" y2="10"></line>
                  <line x1="12" y1="20" x2="12" y2="4"></line>
                  <line x1="6" y1="20" x2="6" y2="14"></line>
                </svg>
                Graph View
              </Button>
            </div>
            
            {/* Detailed Stats Section */}
            {activeView === 'stats' && (
              <DetailedStats plantData={plantData} />
            )}
            
            {/* Graph View Section */}
            {activeView === 'graph' && (
              <GraphView plantData={plantData} />
            )}
          </>
        )}
      </main>
    </div>
  );
};

export default Dashboard;