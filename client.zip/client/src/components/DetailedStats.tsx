import { Card, CardContent } from '@/components/ui/card';
import { PlantDataType } from '@/hooks/usePlantData';

interface DetailedStatsProps {
  plantData: PlantDataType | null;
}

export const DetailedStats = ({ plantData }: DetailedStatsProps) => {
  const formatTimestamp = (timestamp: number) => {
    const now = Date.now();
    const diff = now - timestamp;
    
    if (diff < 60000) {
      return 'Just now';
    } else if (diff < 3600000) {
      return `${Math.floor(diff / 60000)} minutes ago`;
    } else if (diff < 86400000) {
      return `${Math.floor(diff / 3600000)} hours ago`;
    } else {
      return `${Math.floor(diff / 86400000)} days ago`;
    }
  };

  const getMoistureStatus = (value: number) => {
    if (value >= 65 && value <= 75) {
      return { text: 'Optimal', color: 'text-green-500' };
    } else if (value >= 55 && value < 65) {
      return { text: 'Slightly Dry', color: 'text-yellow-500' };
    } else if (value > 75 && value <= 85) {
      return { text: 'Slightly Wet', color: 'text-yellow-500' };
    } else if (value < 55) {
      return { text: 'Too Dry', color: 'text-red-500' };
    } else {
      return { text: 'Too Wet', color: 'text-red-500' };
    }
  };

  const getSunlightStatus = (value: number) => {
    if (value >= 800 && value <= 1200) {
      return { text: 'Optimal', color: 'text-green-500' };
    } else if (value >= 600 && value < 800) {
      return { text: 'Slightly Low', color: 'text-yellow-500' };
    } else if (value > 1200 && value <= 1400) {
      return { text: 'Slightly High', color: 'text-yellow-500' };
    } else if (value < 600) {
      return { text: 'Too Low', color: 'text-red-500' };
    } else {
      return { text: 'Too High', color: 'text-red-500' };
    }
  };

  const moistureStatus = getMoistureStatus(plantData?.moisture || 0);
  const sunlightStatus = getSunlightStatus(plantData?.sunlight || 0);

  return (
    <Card className="bg-white rounded-xl shadow-md mb-6">
      <CardContent className="p-6">
        <h3 className="text-xl font-poppins font-medium mb-4">Detailed Statistics</h3>
        
        <div className="space-y-6">
          <div>
            <h4 className="font-medium text-gray-700 mb-2">Soil Moisture</h4>
            <div className="bg-gray-100 p-4 rounded-lg">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Current Value</p>
                  <p className="text-lg font-medium">{plantData?.moisture || 0}%</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Optimal Range</p>
                  <p className="text-lg font-medium">65-75%</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Last Updated</p>
                  <p className="text-lg font-medium">
                    {plantData?.lastUpdated ? formatTimestamp(plantData.lastUpdated) : 'N/A'}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Status</p>
                  <p className={`text-lg font-medium ${moistureStatus.color}`}>
                    {moistureStatus.text}
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <h4 className="font-medium text-gray-700 mb-2">Sunlight</h4>
            <div className="bg-gray-100 p-4 rounded-lg">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Current Value</p>
                  <p className="text-lg font-medium">{plantData?.sunlight || 0} lux</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Optimal Range</p>
                  <p className="text-lg font-medium">800-1200 lux</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Last Updated</p>
                  <p className="text-lg font-medium">
                    {plantData?.lastUpdated ? formatTimestamp(plantData.lastUpdated) : 'N/A'}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Status</p>
                  <p className={`text-lg font-medium ${sunlightStatus.color}`}>
                    {sunlightStatus.text}
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <h4 className="font-medium text-gray-700 mb-2">Air Quality</h4>
            <div className="bg-gray-100 p-4 rounded-lg">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Current Value</p>
                  <p className="text-lg font-medium">
                    {plantData?.airQuality || 'Good'} ({plantData?.co2 || 420} ppm)
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Optimal Range</p>
                  <p className="text-lg font-medium">&lt; 800 ppm</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Last Updated</p>
                  <p className="text-lg font-medium">
                    {plantData?.lastUpdated ? formatTimestamp(plantData.lastUpdated) : 'N/A'}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Status</p>
                  <p className="text-lg font-medium text-green-500">
                    {plantData?.airQuality || 'Good'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default DetailedStats;
