import { useState, useEffect, useRef } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PlantDataType } from '@/hooks/usePlantData';
import { apiRequest } from '@/lib/queryClient';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts';

interface GraphViewProps {
  plantData: PlantDataType | null;
}

interface HistoricalData {
  timestamp: string;
  moisture: number;
  sunlight: number;
  co2: number;
}

export const GraphView = ({ plantData }: GraphViewProps) => {
  const [timeRange, setTimeRange] = useState<'24h' | '7d' | '30d'>('24h');
  const [historicalData, setHistoricalData] = useState<HistoricalData[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Add current data to historical for immediate display
  useEffect(() => {
    if (plantData) {
      const now = new Date();
      setHistoricalData(prev => {
        // Clone the previous data to avoid direct state mutation
        const newData = [...prev];
        
        // Add the new data point
        newData.push({
          timestamp: `${now.getHours()}:${now.getMinutes().toString().padStart(2, '0')}`,
          moisture: plantData.moisture,
          sunlight: plantData.sunlight,
          co2: plantData.co2 || 420
        });
        
        // Keep only the most recent 25 data points
        if (newData.length > 25) {
          return newData.slice(-25);
        }
        
        return newData;
      });
    }
  }, [plantData]);

  // Fetch historical data
  useEffect(() => {
    const fetchHistoricalData = async () => {
      setIsLoading(true);
      try {
        const response = await apiRequest('GET', `/api/plant-history?timeRange=${timeRange}`, undefined);
        const data = await response.json();
        setHistoricalData(data);
      } catch (error) {
        console.error('Failed to fetch historical data:', error);
        // If we can't get real data, create some demo data
        const demoData: HistoricalData[] = [];
        const now = new Date();
        
        let hoursToGoBack;
        switch (timeRange) {
          case '7d':
            hoursToGoBack = 168;
            break;
          case '30d':
            hoursToGoBack = 720;
            break;
          default:
            hoursToGoBack = 24;
        }
        
        for (let i = hoursToGoBack; i >= 0; i--) {
          const date = new Date(now.getTime() - i * 60 * 60 * 1000);
          demoData.push({
            timestamp: `${date.getHours()}:${date.getMinutes().toString().padStart(2, '0')}`,
            moisture: Math.floor(Math.random() * 20) + 60, // 60-80
            sunlight: Math.floor(Math.random() * 400) + 800, // 800-1200
            co2: Math.floor(Math.random() * 100) + 400 // 400-500
          });
        }
        setHistoricalData(demoData);
      } finally {
        setIsLoading(false);
      }
    };

    fetchHistoricalData();
  }, [timeRange]);

  return (
    <Card className="bg-white rounded-xl shadow-md mb-6">
      <CardContent className="p-6">
        <h3 className="text-xl font-poppins font-medium mb-4">Sensor Data History</h3>
        
        <Tabs defaultValue="24h" value={timeRange} onValueChange={(value) => setTimeRange(value as '24h' | '7d' | '30d')}>
          <TabsList className="mb-4">
            <TabsTrigger value="24h">Last 24 Hours</TabsTrigger>
            <TabsTrigger value="7d">Last Week</TabsTrigger>
            <TabsTrigger value="30d">Last Month</TabsTrigger>
          </TabsList>
          
          <TabsContent value={timeRange}>
            {isLoading ? (
              <div className="h-64 flex items-center justify-center">
                <div className="animate-pulse">Loading chart data...</div>
              </div>
            ) : (
              <div className="h-64 md:h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={historicalData}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="timestamp" />
                    <YAxis yAxisId="left" domain={[0, 100]} />
                    <YAxis yAxisId="right" orientation="right" domain={[0, 2000]} />
                    <Tooltip />
                    <Legend />
                    <Line 
                      yAxisId="left"
                      type="monotone" 
                      dataKey="moisture" 
                      name="Soil Moisture (%)" 
                      stroke="#2196F3" 
                      activeDot={{ r: 8 }} 
                    />
                    <Line 
                      yAxisId="right"
                      type="monotone" 
                      dataKey="sunlight" 
                      name="Sunlight (lux)" 
                      stroke="#FFC107" 
                    />
                    <Line 
                      yAxisId="right"
                      type="monotone" 
                      dataKey="co2" 
                      name="CO₂ (ppm)" 
                      stroke="#4CAF50" 
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default GraphView;
