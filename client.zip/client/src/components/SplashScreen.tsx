import { useEffect, useState } from 'react';
import { PlantoLogo } from '@/assets/plantIllustrations';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen = ({ onComplete }: SplashScreenProps) => {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setVisible(false);
      setTimeout(onComplete, 500); // Allow animation to complete
    }, 2500);

    return () => clearTimeout(timer);
  }, [onComplete]);

  if (!visible) return null;

  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center bg-secondary bg-opacity-90 z-50 transition-opacity duration-500">
      <div className="animate-pulse-slow w-32 h-32">
        {PlantoLogo}
      </div>
      <h1 className="text-4xl font-poppins font-semibold text-primary mb-2 animate-fade-in">Planto</h1>
      <p className="text-lg text-primary-dark animate-slide-up">Your Smart Plant Companion</p>
    </div>
  );
};

export default SplashScreen;
