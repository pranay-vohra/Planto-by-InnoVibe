import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface UserData {
  id: number;
  username: string;
  plantName: string;
  plantType: string;
}

interface RegisterData {
  plantName: string;
  plantType: string;
  username: string;
  password: string;
  wifiUsername: string;
  wifiPassword: string;
  email: string;
  contactNumber: string;
}

interface AuthContextType {
  isLoggedIn: boolean;
  isLoading: boolean;
  userData: UserData | null;
  login: (username: string, password: string) => Promise<void>;
  register: (data: RegisterData) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [userData, setUserData] = useState<UserData | null>(null);
  const { toast } = useToast();

  // Check if user is already logged in on mount
  useEffect(() => {
    const checkAuthStatus = async () => {
      try {
        const response = await apiRequest('GET', '/api/auth/check', undefined);
        const data = await response.json();
        setIsLoggedIn(true);
        setUserData(data);
      } catch (error) {
        setIsLoggedIn(false);
        setUserData(null);
      } finally {
        setIsLoading(false);
      }
    };

    checkAuthStatus();
  }, []);

  const login = async (username: string, password: string) => {
    try {
      const response = await apiRequest('POST', '/api/auth/login', { username, password });
      const data = await response.json();
      setIsLoggedIn(true);
      setUserData(data);

      toast({
        title: 'Login Successful',
        description: `Welcome back, ${data.username}!`,
      });
      
      return data;
    } catch (error) {
      setIsLoggedIn(false);
      setUserData(null);
      throw error;
    }
  };

  const register = async (registerData: RegisterData) => {
    try {
      const response = await apiRequest('POST', '/api/auth/register', registerData);
      const data = await response.json();
      setIsLoggedIn(true);
      setUserData(data);

      toast({
        title: 'Registration Successful',
        description: `Welcome, ${data.username}! Your plant ${registerData.plantName} has been registered.`,
      });
      
      return data;
    } catch (error) {
      throw error;
    }
  };

  const logout = async () => {
    try {
      await apiRequest('POST', '/api/auth/logout', undefined);
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      setIsLoggedIn(false);
      setUserData(null);
      toast({
        title: 'Logged out',
        description: 'You have been successfully logged out',
      });
    }
  };

  return (
    <AuthContext.Provider
      value={{
        isLoggedIn,
        isLoading,
        userData,
        login,
        register,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
