import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';

export interface PlantDataType {
  moisture: number;
  sunlight: number;
  airQuality: string;
  airQualityValue: number;
  co2: number;
  mood: number;
  message: string;
  lastUpdated: number;
}

export const usePlantData = () => {
  const { toast } = useToast();
  const [localPlantData, setLocalPlantData] = useState<PlantDataType | null>(null);

  const { data, isLoading, error } = useQuery({
    queryKey: ['/api/plant-status'],
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  useEffect(() => {
    if (data) {
      setLocalPlantData(data);
    }
  }, [data]);

  useEffect(() => {
    if (error) {
      toast({
        title: "Error fetching plant data",
        description: "Could not fetch the latest plant status. Please try again later.",
        variant: "destructive",
      });
    }
  }, [error, toast]);

  return {
    plantData: localPlantData,
    isLoading,
    error,
    refetch: () => {
      // This function is intentionally empty as refetch is handled by the refetchInterval
    }
  };
};
