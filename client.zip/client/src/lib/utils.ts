import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Calculate plant mood based on sensor readings
export function calculateMood(
  moisture: number,
  sunlight: number,
  airQuality: number
): {
  moodValue: number,
  moodText: string,
  message: string
} {
  let mood = 0;

  // Moisture evaluation (0-40 points)
  if (moisture >= 65 && moisture <= 75) {
    mood += 40; // Optimal range
  } else if ((moisture >= 55 && moisture < 65) || (moisture > 75 && moisture <= 85)) {
    mood += 20; // Slightly out of range
  } else {
    mood += 5; // Far out of range
  }

  // Sunlight evaluation (0-40 points)
  if (sunlight >= 800 && sunlight <= 1200) {
    mood += 40; // Optimal range
  } else if ((sunlight >= 600 && sunlight < 800) || (sunlight > 1200 && sunlight <= 1400)) {
    mood += 20; // Slightly out of range
  } else {
    mood += 5; // Far out of range
  }

  // Air quality evaluation (0-20 points)
  if (airQuality <= 600) {
    mood += 20; // Good air quality
  } else if (airQuality > 600 && airQuality <= 800) {
    mood += 10; // Moderate air quality
  } else {
    mood += 5; // Poor air quality
  }

  // Set mood text and message based on mood value
  let moodText: string;
  let message: string;

  if (mood >= 0 && mood <= 20) {
    moodText = "Very Sad 😭";
    message = "I'm not doing well at all. Please check my conditions!";
  } else if (mood > 20 && mood <= 40) {
    moodText = "Sad 😔";
    message = "I'm feeling a bit under the weather today.";
  } else if (mood > 40 && mood <= 60) {
    moodText = "Okay 😐";
    message = "I'm doing okay, but could use some attention.";
  } else if (mood > 60 && mood <= 80) {
    moodText = "Happy 😃";
    message = "I'm feeling great today! Hydrated and sun-kissed.";
  } else {
    moodText = "Very Happy 🥳";
    message = "I'm thriving! Thank you for taking such good care of me!";
  }

  return {
    moodValue: mood,
    moodText,
    message
  };
}

// Generate specific messages based on sensor values
export function generateSpecificMessage(
  moisture: number,
  sunlight: number,
  airQuality: number
): string {
  const messages = [];

  // Check moisture
  if (moisture < 55) {
    messages.push("I'm feeling very thirsty. Could you water me please?");
  } else if (moisture > 85) {
    messages.push("I'm drowning! Too much water!");
  }

  // Check sunlight
  if (sunlight < 600) {
    messages.push("It's too dark here. I need more light to grow!");
  } else if (sunlight > 1400) {
    messages.push("It's too bright! I might get sunburnt!");
  }

  // Check air quality
  if (airQuality > 800) {
    messages.push("The air feels a bit stuffy. Some fresh air would be nice!");
  }

  // If no specific issues, return a general message
  if (messages.length === 0) {
    const generalMessages = [
      "I'm feeling great today! Hydrated and sun-kissed.",
      "What a lovely day! I'm growing so well!",
      "Thanks for taking good care of me!",
      "I'm thriving in this environment!",
      "I feel healthy and strong!"
    ];
    return generalMessages[Math.floor(Math.random() * generalMessages.length)];
  }

  // Return the first specific message
  return messages[0];
}
