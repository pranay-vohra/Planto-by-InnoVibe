import { useState, useEffect } from 'react';
import SplashScreen from '@/components/SplashScreen';
import AuthPage from '@/components/AuthPage';
import Dashboard from '@/components/Dashboard';
import { useAuth } from '@/contexts/AuthContext';

export default function Home() {
  const { isLoggedIn, isLoading } = useAuth();
  const [showSplash, setShowSplash] = useState(true);

  // After splash screen completes, we check if the user is logged in
  const handleSplashComplete = () => {
    setShowSplash(false);
  };

  // If we're on initial render, show the splash screen
  if (showSplash) {
    return <SplashScreen onComplete={handleSplashComplete} />;
  }

  // If we're still loading auth state, show a loading indicator
  if (isLoading) {
    return (
      <div className="min-h-screen flex justify-center items-center">
        <div className="animate-pulse text-primary">Loading...</div>
      </div>
    );
  }

  // Show the appropriate page based on auth state
  return isLoggedIn ? <Dashboard /> : <AuthPage />;
}
