import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import DashboardPage from "@/pages/dashboard-page";
import { PlantDataProvider } from "@/hooks/use-plant-data";

function Router() {
  return (
    <Switch>
      <Route path="/" component={AuthPage} />
      <Route path="/dashboard/:id" component={DashboardPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <PlantDataProvider>
          <div className="min-h-screen flex flex-col relative overflow-hidden">
            {/* Translucent plant background */}
            <div 
              className="fixed inset-0 z-0" 
              style={{ 
                backgroundImage: 'url("https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080")', 
                backgroundSize: 'cover', 
                backgroundPosition: 'center', 
                opacity: 0.15 
              }}
            />
            
            <div className="relative flex-1 flex flex-col items-center p-4 md:p-8 z-10">
              <Router />
            </div>
            
            <footer className="mt-auto relative z-10 py-4 text-center text-sm text-secondary">
              <p>© {new Date().getFullYear()} Planto - Smart Plant Care System</p>
            </footer>
          </div>
          <Toaster />
        </PlantDataProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
