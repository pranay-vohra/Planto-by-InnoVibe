import { Alert, AlertTitle } from "@/components/ui/alert";

interface AlertMessageProps {
  message: string;
  icon?: string;
}

export default function AlertMessage({ message, icon = "🌵" }: AlertMessageProps) {
  return (
    <Alert className="glassmorphism rounded-2xl p-4 mb-6 flex items-center justify-center bg-gradient-to-r from-[#FCBF49]/90 to-[#FCBF49]/70 text-white border-[#FCBF49] alert-bounce">
      <span className="text-xl mr-2">{icon}</span>
      <AlertTitle className="font-medium">{message}</AlertTitle>
    </Alert>
  );
}
