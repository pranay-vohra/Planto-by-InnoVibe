import { Button } from "@/components/ui/button";
import { PlantData } from "@shared/schema";
import { Progress } from "@/components/ui/progress";

interface DetailedStatisticsProps {
  plantData: PlantData;
  setActiveTab: (tab: string) => void;
}

export default function DetailedStatistics({ plantData, setActiveTab }: DetailedStatisticsProps) {
  const getStatusText = (value: number): { text: string, color: string } => {
    if (value < 30) return { text: "Low - Action needed", color: "text-red-500" };
    if (value < 50) return { text: "Low - Water needed soon", color: "text-red-500" };
    if (value < 70) return { text: "Good", color: "text-green-500" };
    return { text: "Excellent", color: "text-green-500" };
  };
  
  const statistics = [
    {
      name: "Soil Moisture",
      value: plantData.moistureLevel,
      status: getStatusText(plantData.moistureLevel)
    },
    {
      name: "Air Humidity",
      value: plantData.airHumidity,
      status: getStatusText(plantData.airHumidity)
    },
    {
      name: "Soil Nutrition",
      value: plantData.soilNutrition,
      status: getStatusText(plantData.soilNutrition)
    },
    {
      name: "Light Exposure",
      value: plantData.lightExposure,
      status: getStatusText(plantData.lightExposure)
    }
  ];
  
  return (
    <div className="glassmorphism rounded-3xl shadow-lg p-6 mb-6">
      <h3 className="text-xl font-serif font-bold text-primary mb-4">Detailed Statistics</h3>
      
      <div className="space-y-5">
        {statistics.map((stat) => (
          <div key={stat.name}>
            <div className="flex justify-between mb-1">
              <span className="text-secondary">{stat.name}</span>
              <span className="font-medium text-primary">{stat.value}%</span>
            </div>
            <Progress value={stat.value} className="h-3" />
            <p className={`text-xs ${stat.status.color} mt-1`}>{stat.status.text}</p>
          </div>
        ))}
      </div>
      
      <div className="mt-6">
        <Button 
          onClick={() => setActiveTab("dashboard")} 
          variant="outline" 
          className="w-full border border-primary text-primary hover:bg-primary hover:text-white"
        >
          Back to Dashboard
        </Button>
      </div>
    </div>
  );
}
