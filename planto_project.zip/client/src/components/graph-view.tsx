import { useMemo } from "react";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { PlantData } from "@shared/schema";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

interface GraphViewProps {
  plantDataHistory: PlantData[];
  setActiveTab: (tab: string) => void;
}

export default function GraphView({ plantDataHistory, setActiveTab }: GraphViewProps) {
  const chartData = useMemo(() => {
    return plantDataHistory.map(data => ({
      day: format(new Date(data.timestamp), 'EEE'),
      moisture: data.moistureLevel,
      humidity: data.airHumidity,
      nutrition: data.soilNutrition,
      light: data.lightExposure,
      date: format(new Date(data.timestamp), 'MMM dd')
    }));
  }, [plantDataHistory]);
  
  return (
    <div className="glassmorphism rounded-3xl shadow-lg p-6 mb-6">
      <h3 className="text-xl font-serif font-bold text-primary mb-4">Growth Metrics</h3>
      
      <div className="bg-white rounded-xl p-4 mb-5">
        <div className="flex justify-between items-center mb-3">
          <h4 className="font-medium text-secondary">Plant Health Metrics</h4>
          <div className="text-xs text-gray-500">Updated {format(new Date(), 'MMM dd')}</div>
        </div>
        
        <div className="h-60 w-full" id="moisture-chart">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              margin={{
                top: 5,
                right: 5,
                left: -20,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
              <XAxis dataKey="day" fontSize={12} />
              <YAxis fontSize={12} tickFormatter={(value) => `${value}%`} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'white', 
                  borderRadius: '8px',
                  border: 'none',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                }}
                formatter={(value) => [`${value}%`]}
                labelFormatter={(label) => {
                  const entry = chartData.find(item => item.day === label);
                  return entry ? entry.date : label;
                }}
              />
              <Legend />
              <Bar dataKey="moisture" name="Moisture" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} />
              <Bar dataKey="humidity" name="Humidity" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} />
              <Bar dataKey="nutrition" name="Nutrition" fill="hsl(var(--chart-3))" radius={[4, 4, 0, 0]} />
              <Bar dataKey="light" name="Light" fill="hsl(var(--chart-4))" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
      
      <div className="mt-6">
        <Button 
          onClick={() => setActiveTab("dashboard")}
          variant="outline" 
          className="w-full border border-primary text-primary hover:bg-primary hover:text-white"
        >
          Back to Dashboard
        </Button>
      </div>
    </div>
  );
}
