import { Card } from "@/components/ui/card";
import { PlantData } from "@shared/schema";
import { format } from "date-fns";
import { getPlantImage } from "@/lib/plant-types";

interface PlantImageCardProps {
  plantData: PlantData;
  plantType: string;
}

export default function PlantImageCard({ plantData, plantType }: PlantImageCardProps) {
  const plantImage = getPlantImage(plantType);
  const getDateText = (date?: Date) => {
    if (!date) return "Never";
    return format(new Date(date), "PP");
  };

  const formattedLastWatered = plantData.lastWatered 
    ? format(new Date(plantData.lastWatered), "d 'days ago'")
    : "Never watered";
  
  return (
    <Card className="glassmorphism rounded-3xl shadow-lg overflow-hidden">
      <div className="relative">
        <img 
          src={plantImage} 
          alt="Plant" 
          className="w-full h-64 object-cover"
        />
        
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-4 text-white">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm">Last watered</p>
              <p className="font-medium">{formattedLastWatered}</p>
            </div>
            <div>
              <p className="text-sm">Light level</p>
              <p className="font-medium">
                {plantData.lightExposure >= 70 ? "Optimal" : 
                 plantData.lightExposure >= 50 ? "Good" : "Low"}
              </p>
            </div>
            <div>
              <p className="text-sm">Temperature</p>
              <p className="font-medium">{plantData.temperature || 72}°F</p>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}
