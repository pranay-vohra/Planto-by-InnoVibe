import { useState, useEffect, useRef } from "react";
import { Slider } from "@/components/ui/slider";

interface PlantMoodSliderProps {
  mood: number;
  onMoodChange: (mood: number) => void;
}

export default function PlantMoodSlider({ mood, onMoodChange }: PlantMoodSliderProps) {
  const [currentMood, setCurrentMood] = useState(mood);
  const [hasMoodChanged, setHasMoodChanged] = useState(false);
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);
  
  // Handle external updates to mood
  useEffect(() => {
    if (!hasMoodChanged) {
      setCurrentMood(mood);
    }
  }, [mood, hasMoodChanged]);
  
  function getMoodEmoji(mood: number): string {
    if (mood < 30) return "🥲";
    if (mood < 70) return "😊";
    return "🥳";
  }
  
  // Update mood with debounce to avoid too many API calls
  const handleMoodChange = (value: number[]) => {
    const newMood = value[0];
    setCurrentMood(newMood);
    setHasMoodChanged(true);
    
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }
    
    debounceTimerRef.current = setTimeout(() => {
      onMoodChange(newMood);
      setHasMoodChanged(false);
    }, 500);
  };
  
  return (
    <div className="mb-5">
      <div className="flex justify-between mb-2">
        <label htmlFor="mood-slider" className="text-secondary font-medium">Plant Mood</label>
        <span className="text-secondary font-medium">{currentMood}%</span>
      </div>
      
      <Slider
        id="mood-slider"
        defaultValue={[mood]}
        value={[currentMood]}
        max={100}
        step={1}
        onValueChange={handleMoodChange}
        className="mb-4"
      />
      
      <div className="flex justify-center my-4">
        <div className="text-center flex items-center justify-center text-6xl transition-all duration-500 animate-sway">
          <span>{getMoodEmoji(currentMood)}</span>
        </div>
      </div>
    </div>
  );
}
