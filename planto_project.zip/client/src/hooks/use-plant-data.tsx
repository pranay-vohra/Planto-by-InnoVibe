import { createContext, ReactNode, useContext, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Plant, PlantData } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type PlantDataContextType = {
  plant: Plant | null;
  plantData: PlantData | null;
  plantDataHistory: PlantData[];
  isLoading: boolean;
  error: Error | null;
  updatePlantMood: (mood: number) => void;
};

const PlantDataContext = createContext<PlantDataContextType | null>(null);

// This component should be used to wrap the application
export function PlantDataProvider({ children }: { children: ReactNode }) {
  const [plant, setPlant] = useState<Plant | null>(null);
  const [plantData, setPlantData] = useState<PlantData | null>(null);
  const [plantDataHistory, setPlantDataHistory] = useState<PlantData[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const { toast } = useToast();

  const updatePlantMood = async (plantId: number, mood: number) => {
    try {
      const res = await apiRequest("PATCH", `/api/plants/${plantId}/mood`, { mood });
      const updatedData = await res.json();
      
      // Update plant data in context
      setPlantData(updatedData);
      
      // Update plant data history
      setPlantDataHistory(prev => {
        const newHistory = [...prev];
        const lastIndex = newHistory.length - 1;
        if (lastIndex >= 0) {
          newHistory[lastIndex] = updatedData;
        }
        return newHistory;
      });
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: [`/api/plants/${plantId}/data`] });
      
      return updatedData;
    } catch (error) {
      if (error instanceof Error) {
        toast({
          title: "Error updating plant mood",
          description: error.message,
          variant: "destructive",
        });
        throw error;
      }
    }
  };

  return (
    <PlantDataContext.Provider
      value={{
        plant,
        plantData,
        plantDataHistory,
        isLoading,
        error,
        updatePlantMood: (mood: number) => {
          if (plant) {
            updatePlantMood(plant.id, mood);
          }
        },
      }}
    >
      {children}
    </PlantDataContext.Provider>
  );
}

export function usePlantData(plantId: number) {
  const context = useContext(PlantDataContext);
  const { toast } = useToast();
  
  // Fetch plant data
  const { data: plant, isLoading: isPlantLoading, error: plantError } = useQuery<Plant>({
    queryKey: [`/api/plants/${plantId}`],
  });
  
  // Fetch current plant data
  const { data: plantData, isLoading: isDataLoading, error: dataError } = useQuery<PlantData>({
    queryKey: [`/api/plants/${plantId}/data`],
    enabled: !!plant,
  });
  
  // Fetch plant data history
  const { data: plantDataHistory = [], isLoading: isHistoryLoading, error: historyError } = useQuery<PlantData[]>({
    queryKey: [`/api/plants/${plantId}/data/history`],
    enabled: !!plant,
  });
  
  // Update plant mood mutation
  const moodMutation = useMutation({
    mutationFn: async (mood: number) => {
      const res = await apiRequest("PATCH", `/api/plants/${plantId}/mood`, { mood });
      return await res.json();
    },
    onSuccess: () => {
      // Invalidate relevant queries to refresh data
      queryClient.invalidateQueries({ queryKey: [`/api/plants/${plantId}/data`] });
      queryClient.invalidateQueries({ queryKey: [`/api/plants/${plantId}/data/history`] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error updating plant mood",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const error = plantError || dataError || historyError || null;
  const isLoading = isPlantLoading || isDataLoading || isHistoryLoading || moodMutation.isPending;
  
  return {
    plant: plant || null,
    plantData: plantData || null,
    plantDataHistory,
    isLoading,
    error: error instanceof Error ? error : null,
    updatePlantMood: (mood: number) => moodMutation.mutate(mood),
  };
}
