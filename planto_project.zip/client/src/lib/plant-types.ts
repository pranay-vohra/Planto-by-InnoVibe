export type PlantType = {
  value: string;
  label: string;
  imageUrl: string;
};

export const plantTypes: PlantType[] = [
  {
    value: "monstera",
    label: "Monstera",
    imageUrl: "https://images.unsplash.com/photo-1614594975525-e45190c55d0b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=800"
  },
  {
    value: "fiddle-leaf",
    label: "Fiddle Leaf Fig",
    imageUrl: "https://images.unsplash.com/photo-1637967886160-fd78dc3ce3ed?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
  },
  {
    value: "snake-plant",
    label: "Snake Plant",
    imageUrl: "https://images.unsplash.com/photo-1593482892290-f54927ae2b7a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
  },
  {
    value: "pothos",
    label: "Pothos",
    imageUrl: "https://images.unsplash.com/photo-1622920883841-5bf72d767225?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
  },
  {
    value: "aloe",
    label: "Aloe Vera",
    imageUrl: "https://images.unsplash.com/photo-1596547609652-9cf5d8639568?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
  },
  {
    value: "orchid",
    label: "Orchid",
    imageUrl: "https://images.unsplash.com/photo-1566907187471-d9a0dd93079d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
  },
  {
    value: "other",
    label: "Other (Custom)",
    imageUrl: "https://images.unsplash.com/photo-1463936575829-25148e1db1b8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
  }
];

export function getPlantImage(type: string): string {
  const plant = plantTypes.find(p => p.value === type);
  return plant?.imageUrl || plantTypes[plantTypes.length - 1].imageUrl;
}
