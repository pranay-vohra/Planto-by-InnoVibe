import { useState } from "react";
import { useParams } from "wouter";
import { usePlantData } from "@/hooks/use-plant-data";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlantImageCard from "@/components/plant-image-card";
import DetailedStatistics from "@/components/detailed-statistics";
import GraphView from "@/components/graph-view";
import PlantMoodSlider from "@/components/plant-mood-slider";
import AlertMessage from "@/components/alert-message";
import { Loader2 } from "lucide-react";

export default function DashboardPage() {
  const { id } = useParams<{ id: string }>();
  const plantId = parseInt(id);
  
  const { 
    plant, 
    plantData, 
    plantDataHistory,
    isLoading, 
    error,
    updatePlantMood
  } = usePlantData(plantId);
  
  const [activeTab, setActiveTab] = useState("dashboard");
  
  if (isLoading) {
    return (
      <div className="w-full flex items-center justify-center min-h-[50vh]">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }
  
  if (error || !plant || !plantData) {
    return (
      <div className="w-full max-w-md mx-auto mt-8">
        <div className="glassmorphism rounded-3xl shadow-lg p-6">
          <h2 className="text-2xl font-serif font-bold text-destructive text-center mb-4">
            Error Loading Plant Data
          </h2>
          <p className="text-center mb-4">
            {error?.message || "Could not find plant data. Please try again later."}
          </p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="w-full max-w-md mx-auto mt-8">
      <div className="text-center mb-4">
        <h2 className="text-2xl font-serif font-bold text-primary">{plant.name}</h2>
        <p className="text-secondary">Your plant buddy</p>
      </div>
      
      {plantData.isThirsty && (
        <AlertMessage message="I'm thirsty! Please water me!" />
      )}
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsContent value="dashboard">
          <PlantImageCard 
            plantData={plantData} 
            plantType={plant.type}
          />
          
          <div className="glassmorphism rounded-3xl shadow-lg overflow-hidden mt-6 p-6">
            <PlantMoodSlider 
              mood={plantData.mood} 
              onMoodChange={(newMood) => updatePlantMood(newMood)} 
            />
            
            <div className="flex flex-col sm:flex-row gap-3 mt-6">
              <button 
                onClick={() => setActiveTab("statistics")}
                className="flex-1 bg-secondary hover:bg-primary text-white font-medium py-3 px-4 rounded-xl transition duration-300 flex items-center justify-center btn-glow"
              >
                <span className="mr-2">📊</span>
                Detailed Statistics
              </button>
              <button 
                onClick={() => setActiveTab("graphs")}
                className="flex-1 bg-secondary hover:bg-primary text-white font-medium py-3 px-4 rounded-xl transition duration-300 flex items-center justify-center btn-glow"
              >
                <span className="mr-2">📈</span>
                Graph View
              </button>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="statistics">
          <DetailedStatistics plantData={plantData} setActiveTab={setActiveTab} />
        </TabsContent>
        
        <TabsContent value="graphs">
          <GraphView plantDataHistory={plantDataHistory} setActiveTab={setActiveTab} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
