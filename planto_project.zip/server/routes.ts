import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPlantSchema, insertPlantDataSchema } from "@shared/schema";
import { z } from "zod";
import { setupAuth } from "./auth";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  setupAuth(app);
  
  // Plant routes
  app.get("/api/plants", async (req, res) => {
    const plants = await storage.getAllPlants();
    res.json(plants);
  });

  app.get("/api/plants/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const plant = await storage.getPlant(id);
    
    if (!plant) {
      return res.status(404).json({ message: "Plant not found" });
    }
    
    res.json(plant);
  });

  app.post("/api/plants", async (req, res) => {
    try {
      const plantData = insertPlantSchema.parse(req.body);
      const newPlant = await storage.createPlant(plantData);
      
      res.status(201).json(newPlant);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid plant data", errors: error.errors });
      }
      
      res.status(500).json({ message: "Failed to create plant" });
    }
  });

  // Plant data routes
  app.get("/api/plants/:id/data", async (req, res) => {
    const plantId = parseInt(req.params.id);
    const plantData = await storage.getPlantData(plantId);
    
    if (!plantData) {
      return res.status(404).json({ message: "Plant data not found" });
    }
    
    res.json(plantData);
  });

  app.get("/api/plants/:id/data/history", async (req, res) => {
    const plantId = parseInt(req.params.id);
    const daysStr = req.query.days as string || "7";
    const days = parseInt(daysStr);
    
    const dataHistory = await storage.getPlantDataHistory(plantId, days);
    res.json(dataHistory);
  });

  app.post("/api/plants/:id/data", async (req, res) => {
    try {
      const plantId = parseInt(req.params.id);
      const data = { ...req.body, plantId };
      const validatedData = insertPlantDataSchema.parse(data);
      
      const newData = await storage.createPlantData(validatedData);
      res.status(201).json(newData);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid plant data", errors: error.errors });
      }
      
      res.status(500).json({ message: "Failed to create plant data" });
    }
  });

  app.patch("/api/plants/:id/mood", async (req, res) => {
    try {
      const plantId = parseInt(req.params.id);
      const { mood } = req.body;
      
      if (typeof mood !== 'number' || mood < 0 || mood > 100) {
        return res.status(400).json({ message: "Mood must be a number between 0 and 100" });
      }
      
      const updatedData = await storage.updatePlantMood(plantId, mood);
      res.json(updatedData);
    } catch (error) {
      res.status(500).json({ message: "Failed to update plant mood" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
