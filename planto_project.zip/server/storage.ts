import { 
  users, 
  plants, 
  plantData, 
  type User, 
  type InsertUser, 
  type Plant, 
  type InsertPlant,
  type PlantData,
  type InsertPlantData
} from "@shared/schema";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getAllPlants(): Promise<Plant[]>;
  getPlant(id: number): Promise<Plant | undefined>;
  createPlant(plant: InsertPlant): Promise<Plant>;
  
  getPlantData(plantId: number): Promise<PlantData | undefined>;
  getPlantDataHistory(plantId: number, days: number): Promise<PlantData[]>;
  createPlantData(data: InsertPlantData): Promise<PlantData>;
  updatePlantMood(plantId: number, mood: number): Promise<PlantData | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private plants: Map<number, Plant>;
  private plantsData: Map<number, PlantData[]>;
  
  private userIdCounter: number;
  private plantIdCounter: number;
  private plantDataIdCounter: number;

  constructor() {
    this.users = new Map();
    this.plants = new Map();
    this.plantsData = new Map();
    
    this.userIdCounter = 1;
    this.plantIdCounter = 1;
    this.plantDataIdCounter = 1;
    
    // Initialize with demo plant data
    this.initDemoData();
  }

  private initDemoData() {
    // Create a demo user
    const demoUser: User = {
      id: this.userIdCounter++,
      username: "demo",
      password: "password"
    };
    this.users.set(demoUser.id, demoUser);
    
    // Create a demo plant
    const demoPlant: Plant = {
      id: this.plantIdCounter++,
      name: "Monstera Deliciosa",
      type: "monstera",
      contact: "user@example.com",
      wifiName: "Home-WiFi",
      userId: demoUser.id,
      createdAt: new Date()
    };
    this.plants.set(demoPlant.id, demoPlant);
    
    // Create initial plant data
    const now = new Date();
    const lastWeek = new Date(now);
    lastWeek.setDate(lastWeek.getDate() - 7);
    
    const initialData: PlantData = {
      id: this.plantDataIdCounter++,
      plantId: demoPlant.id,
      mood: 75,
      moistureLevel: 35,
      airHumidity: 65,
      soilNutrition: 82,
      lightExposure: 70,
      isThirsty: true,
      lastWatered: new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
      temperature: 72,
      timestamp: now
    };
    
    // Create historical data (last 7 days)
    const historyData: PlantData[] = [];
    
    for (let i = 6; i >= 0; i--) {
      const date = new Date(now);
      date.setDate(date.getDate() - i);
      
      historyData.push({
        id: this.plantDataIdCounter++,
        plantId: demoPlant.id,
        mood: 50 + Math.floor(Math.random() * 50),
        moistureLevel: 30 + Math.floor(Math.random() * 60),
        airHumidity: 50 + Math.floor(Math.random() * 40),
        soilNutrition: 70 + Math.floor(Math.random() * 30),
        lightExposure: 60 + Math.floor(Math.random() * 40),
        isThirsty: Math.random() > 0.7,
        lastWatered: i === 2 ? new Date(date) : undefined,
        temperature: 70 + Math.floor(Math.random() * 5),
        timestamp: date
      });
    }
    
    // Add the current data as the latest
    historyData.push(initialData);
    
    this.plantsData.set(demoPlant.id, historyData);
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  async getAllPlants(): Promise<Plant[]> {
    return Array.from(this.plants.values());
  }
  
  async getPlant(id: number): Promise<Plant | undefined> {
    return this.plants.get(id);
  }
  
  async createPlant(plant: InsertPlant): Promise<Plant> {
    const id = this.plantIdCounter++;
    const newPlant: Plant = { 
      ...plant, 
      id,
      createdAt: new Date()
    };
    this.plants.set(id, newPlant);
    
    // Initialize plant data
    const now = new Date();
    const initialData: PlantData = {
      id: this.plantDataIdCounter++,
      plantId: id,
      mood: 75,
      moistureLevel: 50,
      airHumidity: 65,
      soilNutrition: 80,
      lightExposure: 70,
      isThirsty: false,
      lastWatered: now,
      temperature: 72,
      timestamp: now
    };
    
    this.plantsData.set(id, [initialData]);
    
    return newPlant;
  }
  
  async getPlantData(plantId: number): Promise<PlantData | undefined> {
    const plantDataList = this.plantsData.get(plantId);
    if (!plantDataList || plantDataList.length === 0) {
      return undefined;
    }
    
    // Return the most recent data
    return plantDataList[plantDataList.length - 1];
  }
  
  async getPlantDataHistory(plantId: number, days: number): Promise<PlantData[]> {
    const plantDataList = this.plantsData.get(plantId);
    if (!plantDataList) {
      return [];
    }
    
    const now = new Date();
    const startDate = new Date(now);
    startDate.setDate(startDate.getDate() - days);
    
    return plantDataList.filter(data => data.timestamp >= startDate);
  }
  
  async createPlantData(data: InsertPlantData): Promise<PlantData> {
    const id = this.plantDataIdCounter++;
    const newData: PlantData = {
      ...data,
      id,
      timestamp: new Date()
    };
    
    const plantDataList = this.plantsData.get(data.plantId) || [];
    plantDataList.push(newData);
    this.plantsData.set(data.plantId, plantDataList);
    
    return newData;
  }
  
  async updatePlantMood(plantId: number, mood: number): Promise<PlantData | undefined> {
    const currentData = await this.getPlantData(plantId);
    if (!currentData) {
      return undefined;
    }
    
    const plantDataList = this.plantsData.get(plantId);
    if (!plantDataList) {
      return undefined;
    }
    
    // Create a new data entry with updated mood
    const updatedData: PlantData = {
      ...currentData,
      id: this.plantDataIdCounter++,
      mood,
      timestamp: new Date()
    };
    
    plantDataList.push(updatedData);
    this.plantsData.set(plantId, plantDataList);
    
    return updatedData;
  }
}

export const storage = new MemStorage();
