import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const plants = pgTable("plants", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  contact: text("contact").notNull(),
  wifiName: text("wifi_name").notNull(),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const plantData = pgTable("plant_data", {
  id: serial("id").primaryKey(),
  plantId: integer("plant_id").references(() => plants.id),
  mood: integer("mood").notNull(),
  moistureLevel: integer("moisture_level").notNull(),
  airHumidity: integer("air_humidity").notNull(),
  soilNutrition: integer("soil_nutrition").notNull(),
  lightExposure: integer("light_exposure").notNull(),
  isThirsty: boolean("is_thirsty").notNull(),
  lastWatered: timestamp("last_watered"),
  temperature: integer("temperature"),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertPlantSchema = createInsertSchema(plants).pick({
  name: true,
  type: true,
  contact: true,
  wifiName: true,
  userId: true,
});

export const insertPlantDataSchema = createInsertSchema(plantData).pick({
  plantId: true,
  mood: true,
  moistureLevel: true,
  airHumidity: true,
  soilNutrition: true,
  lightExposure: true,
  isThirsty: true,
  lastWatered: true,
  temperature: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertPlant = z.infer<typeof insertPlantSchema>;
export type Plant = typeof plants.$inferSelect;

export type InsertPlantData = z.infer<typeof insertPlantDataSchema>;
export type PlantData = typeof plantData.$inferSelect;
