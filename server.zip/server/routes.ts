import express, { Response, NextFunction } from "express";
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { calculatePlantMood, generatePlantMessage } from "../shared/schema";
import { log } from "./vite";
import session from "express-session";

// Define a custom Request type that includes the session
interface Request extends express.Request {
  session: session.Session & {
    user?: {
      id: number;
      username: string;
      plantName: string;
      plantType: string;
    }
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Create API router
  const apiRouter = express.Router();
  app.use("/api", apiRouter);

  // Login endpoint
  apiRouter.post("/auth/login", async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;

      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }

      const user = await storage.getUserByUsername(username);

      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }

      // Session-based auth (simplified)
      req.session.user = {
        id: user.id,
        username: user.username,
        plantName: user.plantName,
        plantType: user.plantType
      };

      res.json({
        id: user.id,
        username: user.username,
        plantName: user.plantName,
        plantType: user.plantType
      });
    } catch (error) {
      log(`Login error: ${error instanceof Error ? error.message : String(error)}`, "api");
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Register endpoint
  apiRouter.post("/auth/register", async (req: Request, res: Response) => {
    try {
      const userSchema = z.object({
        plantName: z.string().min(1, "Plant name is required"),
        plantType: z.string().min(1, "Plant type is required"),
        username: z.string().min(3, "Username must be at least 3 characters"),
        password: z.string().min(6, "Password must be at least 6 characters"),
        wifiUsername: z.string().min(1, "WiFi username is required"),
        wifiPassword: z.string().min(1, "WiFi password is required"),
        email: z.string().email("Invalid email address"),
        contactNumber: z.string().min(1, "Contact number is required")
      });

      const userData = userSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      // Create user in storage
      const newUser = await storage.createUser(userData);

      // Create ideal sensor values for this plant type
      await storage.createIdealValues(newUser.id, userData.plantType);

      // Create session
      req.session.user = {
        id: newUser.id,
        username: newUser.username,
        plantName: newUser.plantName,
        plantType: newUser.plantType
      };

      res.status(201).json({
        id: newUser.id,
        username: newUser.username,
        plantName: newUser.plantName,
        plantType: newUser.plantType
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors.map(e => e.message) 
        });
      }
      
      log(`Registration error: ${error instanceof Error ? error.message : String(error)}`, "api");
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Check if user is authenticated
  apiRouter.get("/auth/check", (req: Request, res: Response) => {
    if (req.session.user) {
      return res.json(req.session.user);
    }
    res.status(401).json({ message: "Not authenticated" });
  });

  // Logout endpoint
  apiRouter.post("/auth/logout", (req: Request, res: Response) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  // Plant status endpoint - fetches current sensor data and generates plant mood
  apiRouter.get("/plant-status", async (req: Request, res: Response) => {
    try {
      if (!req.session.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const userId = req.session.user.id;
      
      // Get latest sensor data
      const sensorData = await storage.getLatestSensorData(userId);
      
      if (!sensorData) {
        // Generate mock data if no sensor data is available
        const mockData = storage.generateMockSensorData(userId);
        await storage.saveSensorData(mockData);
        
        // Get ideal values for comparison
        const idealValues = await storage.getIdealValues(userId);
        
        // Calculate plant mood and generate message
        const { mood, message } = calculatePlantMood(mockData, idealValues);
        
        return res.json({
          moisture: mockData.moisture,
          sunlight: mockData.sunlight,
          airQuality: mockData.airQuality > 800 ? "Poor" : (mockData.airQuality > 600 ? "Moderate" : "Good"),
          airQualityValue: 100 - ((mockData.airQuality / 1000) * 100), // Convert to 0-100 scale (reversed)
          co2: mockData.airQuality,
          mood,
          message,
          lastUpdated: Date.now()
        });
      }
      
      // Get ideal values for this plant
      const idealValues = await storage.getIdealValues(userId);
      
      // Calculate plant mood and generate message
      const { mood, message } = calculatePlantMood(sensorData, idealValues);
      
      res.json({
        moisture: sensorData.moisture,
        sunlight: sensorData.sunlight,
        airQuality: sensorData.airQuality > 800 ? "Poor" : (sensorData.airQuality > 600 ? "Moderate" : "Good"),
        airQualityValue: 100 - ((sensorData.airQuality / 1000) * 100), // Convert to 0-100 scale (reversed)
        co2: sensorData.airQuality,
        mood,
        message,
        lastUpdated: sensorData.timestamp
      });
    } catch (error) {
      log(`Plant status error: ${error instanceof Error ? error.message : String(error)}`, "api");
      res.status(500).json({ message: "Failed to get plant status" });
    }
  });

  // Plant history endpoint - returns historical sensor data for graphs
  apiRouter.get("/plant-history", async (req: Request, res: Response) => {
    try {
      if (!req.session.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const userId = req.session.user.id;
      const timeRange = req.query.timeRange as string || '24h';
      
      // Get historical data based on time range
      const historicalData = await storage.getHistoricalData(userId, timeRange);
      
      res.json(historicalData);
    } catch (error) {
      log(`Plant history error: ${error instanceof Error ? error.message : String(error)}`, "api");
      res.status(500).json({ message: "Failed to get historical data" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
