import { users, type User, type InsertUser, type SensorData, type IdealValues, generatePlantMessage } from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Sensor data operations
  getLatestSensorData(userId: number): Promise<SensorData | undefined>;
  saveSensorData(data: SensorData): Promise<void>;
  getHistoricalData(userId: number, timeRange: string): Promise<any[]>;
  generateMockSensorData(userId: number): SensorData;
  
  // Ideal values operations
  getIdealValues(userId: number): Promise<IdealValues>;
  createIdealValues(userId: number, plantType: string): Promise<void>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private sensorData: Map<number, SensorData[]>; // userId -> array of sensor readings
  private idealValues: Map<number, IdealValues>; // userId -> ideal plant values
  currentId: number;

  constructor() {
    this.users = new Map();
    this.sensorData = new Map();
    this.idealValues = new Map();
    this.currentId = 1;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    
    // Initialize empty sensor data array for this user
    this.sensorData.set(id, []);
    
    return user;
  }

  // Sensor data operations
  async getLatestSensorData(userId: number): Promise<SensorData | undefined> {
    const userSensorData = this.sensorData.get(userId) || [];
    return userSensorData.length > 0 ? userSensorData[userSensorData.length - 1] : undefined;
  }

  async saveSensorData(data: SensorData): Promise<void> {
    const userSensorData = this.sensorData.get(data.userId) || [];
    userSensorData.push(data);
    this.sensorData.set(data.userId, userSensorData);
    
    // Keep only the last 100 readings
    if (userSensorData.length > 100) {
      this.sensorData.set(data.userId, userSensorData.slice(-100));
    }
  }

  async getHistoricalData(userId: number, timeRange: string): Promise<any[]> {
    const userSensorData = this.sensorData.get(userId) || [];
    const now = Date.now();
    
    let timeThreshold: number;
    switch (timeRange) {
      case '7d':
        timeThreshold = now - 7 * 24 * 60 * 60 * 1000; // 7 days
        break;
      case '30d':
        timeThreshold = now - 30 * 24 * 60 * 60 * 1000; // 30 days
        break;
      default:
        timeThreshold = now - 24 * 60 * 60 * 1000; // 24 hours
    }
    
    // Filter data by time threshold and format for charts
    return userSensorData
      .filter(data => data.timestamp >= timeThreshold)
      .map(data => {
        const date = new Date(data.timestamp);
        return {
          timestamp: `${date.getHours()}:${date.getMinutes().toString().padStart(2, '0')}`,
          moisture: data.moisture,
          sunlight: data.sunlight,
          co2: data.airQuality
        };
      });
  }

  generateMockSensorData(userId: number): SensorData {
    const idealValues = this.idealValues.get(userId);
    
    // Generate data that's usually around the ideal values but with some variance
    return {
      userId,
      moisture: Math.floor(Math.random() * 30) + 55, // 55-85
      sunlight: Math.floor(Math.random() * 800) + 600, // 600-1400
      airQuality: Math.floor(Math.random() * 400) + 400, // 400-800 (CO2 ppm)
      timestamp: Date.now()
    };
  }

  // Ideal values operations
  async getIdealValues(userId: number): Promise<IdealValues> {
    return this.idealValues.get(userId) || this.getDefaultIdealValues();
  }

  async createIdealValues(userId: number, plantType: string): Promise<void> {
    const idealValues = this.getIdealValuesByPlantType(plantType);
    this.idealValues.set(userId, idealValues);
  }

  private getIdealValuesByPlantType(plantType: string): IdealValues {
    switch (plantType) {
      case 'succulent':
        return {
          moistureMin: 30,
          moistureMax: 50,
          sunlightMin: 1000,
          sunlightMax: 1500,
          airQualityMax: 800
        };
      case 'fern':
        return {
          moistureMin: 65,
          moistureMax: 85,
          sunlightMin: 400,
          sunlightMax: 800,
          airQualityMax: 800
        };
      case 'flowering':
        return {
          moistureMin: 60,
          moistureMax: 75,
          sunlightMin: 800,
          sunlightMax: 1200,
          airQualityMax: 800
        };
      case 'tropical':
        return {
          moistureMin: 65,
          moistureMax: 80,
          sunlightMin: 600,
          sunlightMax: 1000,
          airQualityMax: 800
        };
      case 'herb':
        return {
          moistureMin: 55,
          moistureMax: 70,
          sunlightMin: 800,
          sunlightMax: 1400,
          airQualityMax: 800
        };
      default:
        return this.getDefaultIdealValues();
    }
  }

  private getDefaultIdealValues(): IdealValues {
    return {
      moistureMin: 65,
      moistureMax: 75,
      sunlightMin: 800,
      sunlightMax: 1200,
      airQualityMax: 800
    };
  }
}

export const storage = new MemStorage();
