import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  plantName: text("plant_name").notNull(),
  plantType: text("plant_type").notNull(),
  wifiUsername: text("wifi_username").notNull(),
  wifiPassword: text("wifi_password").notNull(),
  email: text("email").notNull(),
  contactNumber: text("contact_number").notNull(),
});

// Sensor data table
export const sensorDataTable = pgTable("sensor_data", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  moisture: integer("moisture").notNull(), // percentage
  sunlight: integer("sunlight").notNull(), // lux
  airQuality: integer("air_quality").notNull(), // CO2 ppm
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// Ideal values table
export const idealValuesTable = pgTable("ideal_values", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().unique(),
  moistureMin: integer("moisture_min").notNull(),
  moistureMax: integer("moisture_max").notNull(),
  sunlightMin: integer("sunlight_min").notNull(),
  sunlightMax: integer("sunlight_max").notNull(),
  airQualityMax: integer("air_quality_max").notNull(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users);
export const insertSensorDataSchema = createInsertSchema(sensorDataTable);
export const insertIdealValuesSchema = createInsertSchema(idealValuesTable);

// Additional type definitions
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type SensorData = {
  userId: number;
  moisture: number;
  sunlight: number;
  airQuality: number;
  timestamp: number;
};

export type IdealValues = {
  moistureMin: number;
  moistureMax: number;
  sunlightMin: number;
  sunlightMax: number;
  airQualityMax: number;
};

// Plant utilities
export const plantUtils = {
  calculateMood: (sensorData: SensorData, idealValues: IdealValues): number => {
    let mood = 0;
    
    // Moisture evaluation (0-40 points)
    if (sensorData.moisture >= idealValues.moistureMin && sensorData.moisture <= idealValues.moistureMax) {
      mood += 40; // Optimal range
    } else if (
      (sensorData.moisture >= idealValues.moistureMin - 10 && sensorData.moisture < idealValues.moistureMin) || 
      (sensorData.moisture > idealValues.moistureMax && sensorData.moisture <= idealValues.moistureMax + 10)
    ) {
      mood += 20; // Slightly out of range
    } else {
      mood += 5; // Far out of range
    }
    
    // Sunlight evaluation (0-40 points)
    if (sensorData.sunlight >= idealValues.sunlightMin && sensorData.sunlight <= idealValues.sunlightMax) {
      mood += 40; // Optimal range
    } else if (
      (sensorData.sunlight >= idealValues.sunlightMin - 200 && sensorData.sunlight < idealValues.sunlightMin) || 
      (sensorData.sunlight > idealValues.sunlightMax && sensorData.sunlight <= idealValues.sunlightMax + 200)
    ) {
      mood += 20; // Slightly out of range
    } else {
      mood += 5; // Far out of range
    }
    
    // Air quality evaluation (0-20 points)
    if (sensorData.airQuality <= idealValues.airQualityMax * 0.75) {
      mood += 20; // Good air quality
    } else if (sensorData.airQuality <= idealValues.airQualityMax) {
      mood += 10; // Moderate air quality
    } else {
      mood += 5; // Poor air quality
    }
    
    return mood;
  }
};

export function calculatePlantMood(
  sensorData: SensorData, 
  idealValues: IdealValues
): { mood: number, message: string } {
  const mood = plantUtils.calculateMood(sensorData, idealValues);
  const message = generatePlantMessage(sensorData, idealValues, mood);
  
  return {
    mood,
    message
  };
}

export function generatePlantMessage(
  sensorData: SensorData,
  idealValues: IdealValues,
  mood: number
): string {
  // First check for specific conditions
  if (sensorData.moisture < idealValues.moistureMin - 10) {
    return "I'm feeling very thirsty. Could you water me please?";
  } 
  
  if (sensorData.moisture > idealValues.moistureMax + 10) {
    return "I'm drowning! Too much water!";
  }
  
  if (sensorData.sunlight < idealValues.sunlightMin - 200) {
    return "It's too dark here. I need more light to grow!";
  }
  
  if (sensorData.sunlight > idealValues.sunlightMax + 200) {
    return "It's too bright! I might get sunburnt!";
  }
  
  if (sensorData.airQuality > idealValues.airQualityMax) {
    return "The air feels a bit stuffy. Some fresh air would be nice!";
  }
  
  // If no specific issues, return message based on mood
  if (mood >= 0 && mood <= 20) {
    return "I'm not doing well at all. Please check my conditions!";
  } 
  
  if (mood > 20 && mood <= 40) {
    return "I'm feeling a bit under the weather today.";
  } 
  
  if (mood > 40 && mood <= 60) {
    return "I'm doing okay, but could use some attention.";
  } 
  
  if (mood > 60 && mood <= 80) {
    return "I'm feeling great today! Hydrated and sun-kissed.";
  }
  
  return "I'm thriving! Thank you for taking such good care of me!";
}
